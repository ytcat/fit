# Brick — art review handoff, not approved to merge
**The files in `review-base/` and `editable/` are an earlier editable Blender/GLB candidate. They do not reproduce the exact later neck-fit review. Do not install them as the finished Brick.** The body is provided as a profile for the existing game rig, not as a standalone full-body GLB. The still and video in `reference/` are the newer visual direction. The video predates the narrower neck in the still and is silent.

- Review the assets on a private test branch from the current game, keeping the existing Brick as fallback. Do not apply old cast patches, replace other characters, or touch production.
- Keep the established bulldog face and broad heavyweight shoulders; use the narrower neck in the comparison. Remove the prominent neck fold and smooth the front and back neck seam without smoothing away the facial folds.
- Keep gloves clear of the muzzle, each other, and the torso throughout entry to guard and return, not just in a still. Bigger gloves were requested, but the first enlargement clipped; do not claim it passed. Keep the stock game rig, contact points, and fight logic.
- The editable base has face bones. It does not prove that the later face can speak or that lip sync, contact, or Super Punch are ready. Keep those as separate checks.
- Show the owner a matched phone-sized profile/three-quarter view and a brief guard-entry video of the actual candidate. Wait for owner approval before merging. No version bump or production deployment.
