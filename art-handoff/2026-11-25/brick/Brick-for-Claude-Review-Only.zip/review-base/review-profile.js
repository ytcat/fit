/* Brick only, opt-in art review. These dimensions are absolute StoryCast.bulk
   coefficients, not joint offsets: heavyweight garment follows the stock rig. */
(() => {
  const profiles = window.StoryCastReviewProfiles ||= {};
  const tune=(t)=>{t=Math.max(0,Math.min(1,t));return t*t*(3-2*t);};
  const bell=(v,center,r)=>Math.exp(-((v-center)**2)/(r*r));
  const bell2=(a,b)=>Math.exp(-(a*a+b*b));
  function athleticTorso(rig,THREE){
    const skin=rig.skin, g=skin?.geometry, a=g?.getAttribute('position'), col=g?.getAttribute('color');
    if (!a || !col) return;
    // Retarget only the skin rest surface; keep indices, bind weights and
    // every bone. Broad pecs taper to a more visible ribcage, narrower hips,
    // delt cap and triceps separate from forearm. No sculpted muscle objects.
    for(let i=0;i<a.count;i++){
      const x=a.getX(i), y=a.getY(i), z=a.getZ(i), u=Math.abs(x), sd=Math.sign(x)||1;
      const f=tune((z+.015)/.15), side=tune((u-.255)/.18);
      const chest=bell2((u-.154)/.106,(y-1.516+(u-.14)*.21)/.078);
      const pecUnder=bell(y,1.422+(u-.11)*-.19,.029)*bell(u,.143,.127);
      const abSide=bell(u,.074,.050)*(.010*bell(y,1.335,.040)+.008*bell(y,1.260,.043)+.006*bell(y,1.187,.042));
      const waist=bell(y,1.15,.102)*tune((u-.145)/.095)*(1-side);
      const frontRib=f*(1-side)*tune((y-1.05)/.07)*(1-tune((y-1.66)/.067));
      const outerDelt=.012*bell2((u-.421)/.075,(y-1.605)/.071);
      const tricep=.0075*bell2((u-.565)/.093,(y-1.629)/.054);
      const forearm=.0055*bell2((u-.712)/.080,(y-1.624)/.059);
      const upperArm=tune((y-1.46)/.068)*(1-tune((y-1.70)/.075));
      a.setX(i,x-sd*.020*waist);
      a.setZ(i,z+frontRib*(.010*chest-.0055*pecUnder+abSide)+Math.sign(z)*upperArm*(outerDelt+tricep+forearm));
      if(y>1.40&&u>.30){
        const down=Math.sign(y-1.615),strength=outerDelt*.42+tricep*.25+forearm*.18;
        a.setY(i,y+down*strength*upperArm);
      }
    }
    a.needsUpdate=true;g.computeVertexNormals();g.computeBoundingBox();g.computeBoundingSphere();

    // Low-contrast pigment keeps Brick identifiable without the heavy white
    // vest or dark oversized arm patches that visually divided his torso.
    const base=new THREE.Color('#ae7d55').convertSRGBToLinear();
    const warm=new THREE.Color('#936142').convertSRGBToLinear();
    const cream=new THREE.Color('#d3ad88').convertSRGBToLinear();
    const ivory=new THREE.Color('#ddd1bc').convertSRGBToLinear();
    const dark=new THREE.Color('#78594a').convertSRGBToLinear();
    const c=new THREE.Color();
    for(let i=0;i<a.count;i++){
      const x=a.getX(i),y=a.getY(i),z=a.getZ(i),u=Math.abs(x);
      const f=tune((z+.005)/.15),rear=tune((-z-.01)/.15),uArm=tune((u-.34)/.15);
      const neck=tune((y-1.53)/.22)*(1-tune((u-.17)/.18));
      const patch=.29*(.72*bell2((x-.246)/.120,(y-1.57)/.138)+.55*bell2((x+.180)/.123,(y-.807)/.116));
      const underPec=bell(y,1.431-(u-.1)*.19,.027)*bell(u,.153,.112)*(1-uArm);
      const linea=bell(u,0,.022)*tune((y-1.13)/.085)*(1-tune((y-1.42)/.072));
      const abSep=bell(u,.075,.067)*(.6*bell(y,1.289,.018)+.42*bell(y,1.215,.021));
      const armSide=tune((u-.365)/.13)*tune((y-1.46)/.110)*(1-tune((y-1.68)/.067));
      const softGroove=.071*underPec+.091*linea+.067*abSep;
      c.copy(base).lerp(warm,.43*rear+.13*tune((u-.37)/.38)).lerp(cream,.32*f).lerp(ivory,.80*neck*f);
      c.lerp(dark,patch*(.67+.33*rear));
      c.multiplyScalar(1-f*softGroove-.043*rear-.037*armSide*tune((-z+.008)/.105));
      col.setXYZ(i,c.r,c.g,c.b);
    }
    col.needsUpdate=true;
    // Keep the native posed-skin shader and its live muscle normal/crease
    // uniforms, but make the stubble-scale bump 0.42 mm rather than plush.
    skin.material.bumpScale=.00042;skin.material.roughness=.74;skin.material.needsUpdate=true;
    const look=rig.definition?.look?.value;if(look){look.x=Math.min(.55,look.x*1.18);look.y=Math.min(.64,Math.max(1,look.y)*.38);}
    rig.bodyFurOff=true;if(rig.bodyFur)rig.bodyFur.visible=false;
  }
  profiles.brick = {
    bodyFurOff: true,
    body: { torso: .199, depth: .224, belly: .024, bellyY: 1.25, bellyH: .17,
      chest: .048, arm: .194, leg: .146, neck: 1.32, hips: .059,
      back: .051, traps: .062, dewlap: .037 },
    palette: { shorts: '#28282c', stripe: '#742530', trim: '#ac8052', gloves: '#70313b', boots: '#27292e', sole: '#a78f77' },
    head: { scale: 1.0, offset: [0,-.029,-.003], cut: 1.740, shoulderLift: true, jaw: .22 },
    dress({rig,THREE}) {
      athleticTorso(rig,THREE);
      // Paint curved inserts, double piping and stitches into the real skinned
      // trunk geometry. Seam positions follow the original joint weights.
      const g=rig.shorts?.geometry, a=g?.getAttribute('position');
      if (!a) return {all:[]};
      const c=new Float32Array(a.count*3), co=new THREE.Color();
      // Heavyweight hip ease. Move the actual skinned cloth, above the thigh
      // opening and under the belt, instead of masking skin or altering binds.
      const ease=(t)=>{t=Math.max(0,Math.min(1,t));return t*t*(3-2*t);};
      for(let i=0;i<a.count;i++){
        const x=a.getX(i),y=a.getY(i),z=a.getZ(i),sx=Math.sign(x)||1;
        const field=.024*ease((Math.abs(x)-.185)/.11)*ease((y-.77)/.080)*ease((1.03-y)/.035);
        a.setX(i,x+sx*field);
        a.setZ(i,z+Math.sign(z)*field*.47*ease(Math.abs(z)/.11));
      }
      a.needsUpdate=true;g.computeBoundingBox();g.computeBoundingSphere();
      const black=new THREE.Color('#272830').convertSRGBToLinear();
      const red=new THREE.Color('#722c38').convertSRGBToLinear();
      const tan=new THREE.Color('#c5a177').convertSRGBToLinear();
      const curve=(t)=>{t=Math.max(0,Math.min(1,t)); return t*t*(3-2*t);};
      const clamp=v=>Math.max(0,Math.min(1,v));
      for (let i=0;i<a.count;i++){
        const x=Math.abs(a.getX(i)), y=a.getY(i), z=a.getZ(i);
        const e=Math.max(0,x-(.145+(1-y)*.095));
        const phi=Math.atan2(z,e+.0001);
        const side=Math.abs(phi+.14+(.99-y)*.45);
        const panel=curve((.68-side)/.18)*curve((x-.195)/.065);
        const pipe=Math.exp(-(((side-.61)/.037)**2))*curve((x-.21)/.055);
        const seam=(Math.exp(-(((y-.755)/.013)**2))*.4+pipe*.86);
        const fold=.042*Math.sin(50*z+13*y)+.028*Math.cos(90*y+10*x)+.017*Math.sin(195*y+110*z);
        co.copy(black).lerp(red,.94*panel).lerp(tan,clamp(seam)).multiplyScalar(1+fold);
        c.set([co.r,co.g,co.b],i*3);
      }
      g.setAttribute('color',new THREE.BufferAttribute(c,3));
      if (rig.shorts.material) {
        const m=rig.shorts.material.clone();
        m.vertexColors=true;m.color.set(0xffffff);m.roughness=.77;
        rig.shorts.material=m;
      }
      // A brass double thread hugs each curved cuff. The geometry shares the
      // stock hand bone, so the artwork never changes wrist placement or IK.
      const all=[];
      const thread=new THREE.MeshStandardMaterial({color:'#b79367',roughness:.86});
      const strap=new THREE.MeshStandardMaterial({color:'#282327',roughness:.77});
      for(const side of ['L','R']){
        const hand=rig.joints?.['hand'+side];if(!hand) continue;
        for(const part of hand.children) if(part.name==='Oval wrist strap'){part.material=strap;part.scale.x*=1.07;part.scale.z*=1.09;}
        for(const y of [-.015,.041]){
          const points=Array.from({length:33},(_,i)=>{
            const t=i/32*Math.PI*2;return new THREE.Vector3(.063*Math.cos(t),y,.056*Math.sin(t));
          });
          const mesh=new THREE.Mesh(new THREE.TubeGeometry(new THREE.CatmullRomCurve3(points),32,.0013,5,false),thread);
          mesh.name='Brick • cuff double piping'; mesh.userData.storyPart=true;hand.add(mesh);all.push(mesh);
        }
      }
      return {all};
    }
  };
})();
