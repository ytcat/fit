import bpy,bmesh,os,math,sys
from mathutils import Vector
from math import sin,cos,pi,sqrt
D=os.path.dirname(os.path.abspath(__file__))
bpy.ops.wm.read_factory_settings(use_empty=True)
def m(n,c,r,met=0):
 x=bpy.data.materials.new(n);x.diffuse_color=(*c,1);x.use_nodes=True;p=x.node_tree.nodes.get('Principled BSDF');p.inputs['Base Color'].default_value=(*c,1);p.inputs['Roughness'].default_value=r;p.inputs['Metallic'].default_value=met;return x
paint=m('Jade enamel',(.055,.29,.25),.27,.33); trim=m('Anthracite polymer',(.023,.035,.042),.52); rubber=m('Tire compound',(.017,.020,.023),.79); glass=m('Smoke-blue glass',(.045,.105,.147),.19,.3); metal=m('Machine-cut alloy',(.41,.44,.46),.31,.62);light=m('Warm headlamp',(.78,.87,.83),.24,.26);rear=m('Ruby taillamp',(.47,.016,.023),.23,.21);paper=m('Slate plate',(.24,.29,.27),.48)
S=bpy.context.scene
car=bpy.data.collections.new('Gloryland delivery van');S.collection.children.link(car)
def obj(n,v,f,ma,smooth=False):
 g=bpy.data.meshes.new(n);g.from_pydata(v,[],f);g.update();o=bpy.data.objects.new(n,g);car.objects.link(o);g.materials.append(ma)
 for p in g.polygons:p.use_smooth=smooth
 return o
def normals(o):
 bpy.context.view_layer.objects.active=o;o.select_set(True);bpy.ops.object.mode_set(mode='EDIT');bpy.ops.mesh.select_all(action='SELECT');bpy.ops.mesh.normals_make_consistent(inside=False);bpy.ops.object.mode_set(mode='OBJECT');o.select_set(False)
def loft(n,R,ma,smooth=False):
 k=len(R[0]); f=[tuple(range(k-1,-1,-1))]
 for i in range(len(R)-1):
  for j in range(k):f.append((i*k+j,i*k+(j+1)%k,(i+1)*k+(j+1)%k,(i+1)*k+j))
 f.append(tuple(range((len(R)-1)*k,len(R)*k)))
 o=obj(n,sum(R,[]),f,ma,smooth);normals(o);return o
def box(n,loc,size,ma,b=.025):
 bpy.ops.mesh.primitive_cube_add(size=1,location=loc);o=bpy.context.object;o.name=n
 for c in list(o.users_collection):c.objects.unlink(o)
 car.objects.link(o);o.dimensions=size;bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);o.data.materials.append(ma)
 if b:
  a=o.modifiers.new('Rounded automotive edge','BEVEL');a.width=b;a.segments=2;a.profile=.54
  bpy.ops.object.modifier_apply(modifier=a.name)
  # Blender's overlap-clamped bevel can leave coincident points on thin lenses/trim.
  bm=bmesh.new();bm.from_mesh(o.data);bmesh.ops.remove_doubles(bm,verts=list(bm.verts),dist=1e-6)
  bmesh.ops.dissolve_degenerate(bm,edges=list(bm.edges),dist=1e-6);bm.to_mesh(o.data);bm.free()
 o.select_set(False);return o
# +X nose. Shaped rocker with real front and rear wheel cutouts; hood and cab use unified painted shell.
xws=[(-2.41,.83,2.11),(-2.35,.95,2.24),(-2.18,1.015,2.30),(-1.92,1.03,2.32),(-1.57,1.03,2.32),(-1.24,1.027,2.32),(-.88,1.025,2.32),(-.51,1.024,2.32),(.26,1.015,2.31),(.59,.999,2.27),(.91,.984,2.13),(1.13,.971,1.88),(1.39,.968,1.38),(1.62,.959,1.285),(1.88,.943,1.254),(2.13,.899,1.196),(2.34,.819,1.105),(2.42,.729,1.00)]
wheels=[-1.27,1.51]
def wcut(x):
 return max([.31]+[.365+sqrt(.442**2-(x-k)**2) for k in wheels if abs(x-k)<.442])
xs=sorted(set(round(x,6) for x in ([x for x,_,_ in xws]+[k+.442*cos(pi*j/12) for k in wheels for j in range(13)])))
def row(x):
 for i in range(1,len(xws)):
  a,b=xws[i-1],xws[i]
  if x<=b[0]+1e-6:
   t=(x-a[0])/(b[0]-a[0]);return a[1]+(b[1]-a[1])*t,a[2]+(b[2]-a[2])*t
wR=[]
for x in xs:
 w,t=row(x);lo=wcut(x); shoulder=t-(.14 if x<1.14 else .09);belt=min(1.26,t-.18)
 pts=[(-w*.78,.28),(-w*.94,lo-.023),(-w,lo+.02),(-w,max(lo+.055,belt-.035)),(-w*.975,belt+.027),(-w*.91,shoulder),(-w*.78,t-.036),(-w*.52,t-.003),(0,t+.01),(w*.52,t-.003),(w*.78,t-.036),(w*.91,shoulder),(w*.975,belt+.027),(w,max(lo+.055,belt-.035)),(w,lo+.02),(w*.94,lo-.023),(w*.78,.28)]
 wR.append([(x,y,z) for y,z in pts])
body=loft('Continuous pressed body, rounded cab and sculpted bonnet',wR,paint,True)
body.data.polygons[0].use_smooth=False;body.data.polygons[-1].use_smooth=False
box('Dark visible undertray',(-.04,0,.34),(4.3,1.54,.17),trim,.06)
# Side glass; evaluate the same shell section to seat panels on the surface.
def sidept(x,z,s):
 w,t=row(x);lo=wcut(x);sh=t-(.14 if x<1.14 else .09);b=min(1.26,t-.18)
 r=[(lo-.023,w*.94),(lo+.02,w),(max(lo+.055,b-.035),w),(b+.027,w*.975),(sh,w*.91),(t-.036,w*.78),(t-.003,w*.52)]
 for (z0,w0),(z1,w1) in zip(r,r[1:]):
  if z<=z1+1e-6 and z1>z0:return (x,s*(w0+(w1-w0)*max(0,(z-z0)/(z1-z0))+.012),z)
 return (x,s*(w*.52+.012),z)
def poly(n,ps,ma):
 o=obj(n,ps,[tuple(range(len(ps)))],ma)
 return o
for s in (-1,1):
 for n,p,ma in [
 ('Front door glass',[(.32,1.43),(.97,1.42),(.75,1.96),(.52,2.12),(.30,2.11)],glass),
 ('Rear cabin window',[(-.44,1.43),(.232,1.43),(.209,2.10),(-.434,2.10)],glass),
 ('Sculpted cargo panel',[(-2.11,1.44),(-.54,1.44),(-.54,2.09),(-2.00,2.1),(-2.11,1.97)],paint)]:
  # Only glazing overlays the exterior. Cargo panel remains clean unmarked enamel.
  if ma==glass:
   # Add midpoints as needed on faceted profile; lower pane follows body.
   poly(n,[sidept(x,z,s) for x,z in p],ma)
 for x in [-.61,.44]:
  o=box('Recessed sliding / driver door handle',(x,s*1.027,1.334),(.135,.024,.036),trim,.011)
  box('Handle upper highlight',(x+.012,s*1.041,1.339),(.085,.010,.012),metal,.003)
 box('Sliding-door track',(-1.52,s*1.017,1.388),(1.14,.018,.021),trim,.006)
 box('Rub rail',(-.41,s*1.037,.925),(2.39,.033,.056),trim,.014)
 box('Mirror support',(1.02,s*1.005,1.504),(.126,.241,.045),trim,.011)
 box('Rounded mirror housing',(1.025,s*1.155,1.546),(.25,.17,.141),trim,.039)
 box('Mirror glass',(.898,s*1.159,1.546),(.013,.125,.098),metal,.013)
# Windscreen strips authored over the actual sloped loft stations, preserving curved body corners.
# Reproject the windshield directly onto the steel loft's actual upper surface.
windXs=sorted(set([.650,1.365]+[x for x in xs if .650<x<1.365]))
def wp(x,k):
 w,t=row(x)
 edge=t-.036; shoulder=t-(.14 if x<1.14 else .09)
 h={-.81:edge+(shoulder-edge)/6.5,-.78:edge,-.52:t-.003,0:t+.01,
     .52:t-.003,.78:edge,.81:edge+(shoulder-edge)/6.5}[k]
 return (x,k*w,h+.012)
factors=[-.81,-.78,-.52,0,.52,.78,.81]
glassV=[wp(x,k) for x in windXs for k in factors]; wn=len(factors)
glassF=[(i*wn+j,i*wn+j+1,(i+1)*wn+j+1,(i+1)*wn+j) for i in range(len(windXs)-1) for j in range(wn-1)]
obj('Continuous sealed windshield',glassV,glassF,glass,True)
# Louvred nose and sculpted fitted bumpers.
box('Wrapped front bumper',(2.245,0,.48),(.375,1.71,.268),trim,.10)
box('Lower front intake',(2.443,0,.494),(.026,.865,.123),rubber,.014)
for z in [.466,.508]:box('Lower grille fin',(2.46,0,z),(.016,.793,.012),metal,.004)
box('Upper radiator face',(2.435,0,.749),(.031,1.03,.276),trim,.049)
for z in [.671,.723,.775,.827]:box('Upper grille blade',(2.455,0,z),(.016,.869,.022),metal,.005)
for s in [-1,1]:
 o=box('Swept lamp bezel',(2.337,s*.69,.873),(.211,.365,.188),trim,.053);o.rotation_euler.z=s*.18
 o=box('Inset front lens',(2.406,s*.693,.886),(.092,.278,.106),light,.042);o.rotation_euler.z=s*.22
 o=box('Recessed daylight strip',(2.452,s*.681,.902),(.014,.191,.019),light,.007);o.rotation_euler.z=s*.21
 o=box('Front indicator',(2.405,s*.783,.864),(.054,.066,.033),rear,.01);o.rotation_euler.z=s*.2
 box('Vertical rear lamp bezel',(-2.349,s*.864,1.146),(.116,.131,.696),trim,.035)
 box('Rear vertical brake lamp',(-2.411,s*.864,1.287),(.052,.095,.407),rear,.025)
 box('Reverse lamp',(-2.411,s*.865,1.006),(.052,.095,.104),light,.015)
for s in (-1,1):
 box('Rear cargo door',(-2.41,s*.389,1.169),(.062,.76,1.54),paint,.054)
 box('High rear window',(-2.448,s*.389,1.608),(.025,.575,.408),glass,.055)
box('Rear step bumper',(-2.396,0,.449),(.252,1.79,.225),trim,.06)
box('Rear release',(-2.451,.119,1.078),(.034,.176,.056),trim,.012)
box('Plain rear plate',(-2.451,.26,.728),(.023,.31,.103),paper,.01)
box('High stop lamp',(-2.388,0,2.04),(.057,.43,.043),rear,.01)
# Three-dimensional curved tire tread, alloy rims, and five spoke details.
def lathe(n,x,y,z,rings,ma,count=20):
 R=[[(x+r*cos(i*2*pi/count),y+d,z+r*sin(i*2*pi/count)) for i in range(count)] for d,r in rings]
 return loft(n,R,ma,True)
for x in wheels:
 for s in (-1,1):
  lathe('Rounded rubber tire',x,s*.892,.369,[(-.142,.275),(-.131,.321),(-.098,.355),(-.061,.369),(.061,.369),(.098,.355),(.131,.321),(.142,.275)],rubber)
  lathe('Bevelled alloy rim',x,s*1.032,.369,[(-.019,.232),(-.009,.246),(.009,.246),(.018,.232)],metal)
  lathe('Inset wheel center',x,s*1.052,.369,[(-.01,.197),(.008,.197)],trim)
  lathe('Central hub cover',x,s*1.069,.369,[(-.01,.076),(.009,.076)],metal)
  for k in range(5):
   a=k*2*pi/5;o=box('Alloy spoke',(x+.14*cos(a),s*1.068,.369+.14*sin(a)),(.129,.025,.034),metal,.009);o.rotation_euler.y=-a
# Only native car mesh exported, studio rig remains editable.
bpy.ops.object.select_all(action='DESELECT')
for o in car.objects:o.select_set(True)
bpy.ops.export_scene.gltf(filepath=os.path.join(D,'gloryland-delivery-van.glb'),export_format='GLB',use_selection=True,export_yup=True,export_texcoords=False,export_tangents=False)
for o in car.objects:o.select_set(False)
S.world=bpy.data.worlds.new('Neutral');S.world.use_nodes=True;S.world.node_tree.nodes.get('Background').inputs[0].default_value=(.105,.145,.18,1);S.world.node_tree.nodes.get('Background').inputs[1].default_value=.4
S.render.engine='CYCLES';S.cycles.samples=64;S.cycles.adaptive_threshold=.03;S.cycles.use_denoising=False
bpy.ops.mesh.primitive_plane_add(size=200,location=(0,0,-.017));bpy.context.object.data.materials.append(m('Studio floor',(.135,.173,.19),.62))
for name,loc,e,sz,c in [('Key',(3,-4,6),1550,5,(1,.89,.78)),('Fill',(0,5,4),1120,6,(.72,.88,1)),('Rim',(-5,1,6),2100,4,(.84,.94,1))]:
 d=bpy.data.lights.new(name,'AREA');d.energy=e;d.shape='DISK';d.size=sz;d.color=c;o=bpy.data.objects.new(name,d);S.collection.objects.link(o);o.location=loc;o.rotation_euler=(-o.location).to_track_quat('-Z','Y').to_euler()
bpy.ops.object.camera_add();cam=bpy.context.object;S.camera=cam;cam.data.type='ORTHO';cam.data.ortho_scale=6.15
S.render.resolution_x=1000;S.render.resolution_y=625;S.render.resolution_percentage=100
for tag,poss in [('front',(7,-6.5,3.35)),('side',(.0,-10,2.1)),('rear',(-7,-5.5,3.45))]:
 cam.location=poss;cam.rotation_euler=(Vector((0,0,1.04))-cam.location).to_track_quat('-Z','Y').to_euler()
 S.render.filepath=os.path.join(D,tag+'.png')
 if tag=='front':
  bpy.context.preferences.filepaths.save_version=0
  bpy.ops.wm.save_as_mainfile(filepath=os.path.join(D,'gloryland-delivery-van.blend'))
 if '--assets-only' not in sys.argv: bpy.ops.render.render(write_still=True)
