import bpy, math, os
from mathutils import Vector
from math import sin,cos,pi,sqrt
OUT=os.path.dirname(os.path.abspath(__file__))
bpy.ops.wm.read_factory_settings(use_empty=True)
sc=bpy.context.scene
car=bpy.data.collections.new('Northline 5 | original city hatchback');sc.collection.children.link(car)
stage=bpy.data.collections.new('Review studio | not exported');sc.collection.children.link(stage)

def mat(name,c,r=.4,m=0,coat=0,emit=0):
 a=bpy.data.materials.new(name);a.diffuse_color=(*c,1);a.use_nodes=True
 p=a.node_tree.nodes['Principled BSDF'];p.inputs['Base Color'].default_value=(*c,1);p.inputs['Roughness'].default_value=r;p.inputs['Metallic'].default_value=m;p.inputs['Coat Weight'].default_value=coat;p.inputs['Coat Roughness'].default_value=.2
 if emit:p.inputs['Emission Color'].default_value=(*c,1);p.inputs['Emission Strength'].default_value=emit
 return a
paint=mat('Deep vermilion pearl',(.24,.019,.013),.30,.40,.30)
dark=mat('Satin black polymer',(.018,.021,.025),.45)
rubber=mat('Tyre rubber',(.013,.014,.015),.72)
glass=mat('Graphite-blue glazing',(.036,.069,.084),.19,.34,.35)
silver=mat('Machined alloy',(.54,.59,.66),.29,.78)
polish=mat('Dark anodized alloy',(.10,.115,.13),.35,.60)
chrome=mat('Brushed trim',(.29,.32,.35),.27,.62)
red=mat('Rear lamp crimson',(.60,.024,.009),.22,.22,.35,.10)
white=mat('Pearl LED lens',(.68,.82,.96),.22,.38,.28,.32)
amber=mat('Amber reflector',(.85,.21,.016),.24,.23,.34,.05)
plate=mat('Plate ceramic',(.73,.74,.71),.45)
textmat=mat('Plate letters',(.035,.044,.05),.62)

def obj(name,v,f,m,smooth=False,col=car):
 d=bpy.data.meshes.new(name);d.from_pydata(v,[],f);d.update()
 o=bpy.data.objects.new(name,d);col.objects.link(o);d.materials.append(m)
 for p in d.polygons:p.use_smooth=smooth
 return o
def relink(o,col):
 for a in list(o.users_collection):a.objects.unlink(o)
 col.objects.link(o)
 return o
def normals(o):
 import bmesh
 bm=bmesh.new();bm.from_mesh(o.data);bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces));bm.to_mesh(o.data);bm.free()
def ring(name,rows,m,smooth=True,cap=True):
 n=len(rows[0]); f=[]
 for k in range(len(rows)-1):
  for j in range(n): f.append((k*n+j,k*n+(j+1)%n,(k+1)*n+(j+1)%n,(k+1)*n+j))
 if cap:f.extend((tuple(reversed(range(n))),tuple(range((len(rows)-1)*n,len(rows)*n))))
 o=obj(name,sum(rows,[]),f,m,smooth);normals(o);return o
def cube(name,p,dim,m,b=.02,col=car):
 bpy.ops.mesh.primitive_cube_add(size=1,location=p);o=relink(bpy.context.object,col);o.name=name;o.dimensions=dim
 bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);o.data.materials.append(m)
 if b:
  q=o.modifiers.new('Rolled edges','BEVEL');q.width=b;q.segments=3
  w=o.modifiers.new('Weighted normals','WEIGHTED_NORMAL');w.keep_sharp=True
 return o
def line(name, pts, radius,m,col=car):
 c=bpy.data.curves.new(name,'CURVE');c.dimensions='3D';c.resolution_u=1;c.bevel_depth=radius;c.resolution_u=1;c.bevel_resolution=1
 q=c.splines.new('POLY');q.points.add(len(pts)-1)
 for a,p in zip(q.points,pts):a.co=(*p,1)
 o=bpy.data.objects.new(name,c);col.objects.link(o);o.data.materials.append(m);return o
# x, side width, hood/deck height, shoulder height; front is +X.
P=[(-2.035,.66,.69,.65),(-1.997,.785,.79,.74),(-1.883,.863,.867,.78),(-1.62,.884,.924,.833),(-1.24,.885,.957,.86),(-.68,.883,.973,.875),(0,.879,.980,.878),(.55,.878,.974,.87),(.92,.883,.937,.853),(1.30,.887,.885,.814),(1.64,.867,.829,.762),(1.86,.819,.771,.718),(2.005,.723,.695,.657),(2.035,.60,.61,.59)]
axles=(-1.214,1.202); rad=.323; ctr=.325; arch=.379
def cat(x,idx):
 for i in range(len(P)-1):
  if x<=P[i+1][0]:
   lo,hi=P[i],P[i+1];l=P[max(0,i-1)];h=P[min(i+2,len(P)-1)];dx=hi[0]-lo[0];t=max(0,min(1,(x-lo[0])/dx));a=lo[idx];b=hi[idx]
   da=(b-l[idx])/(hi[0]-l[0])*dx; db=(h[idx]-a)/(h[0]-lo[0])*dx
   return (2*t**3-3*t*t+1)*a+(t**3-2*t*t+t)*da+(-2*t**3+3*t*t)*b+(t**3-t*t)*db
 return P[-1][idx]
def cut(x):
 z=.215+.07*max(0,(abs(x)-1.61)/.43)**1.3
 for a in axles:
  dx=abs(x-a)
  if dx<arch:
   z=max(z,ctr+sqrt(max(0,arch*arch-dx*dx)))
  elif dx<arch+.057:
   t=(dx-arch)/.057
   z=max(z,ctr*(1-t)+z*t)
 return z
xs=sorted(set([round(P[0][0]+(P[-1][0]-P[0][0])*i/70,5) for i in range(71)]+[k[0] for k in P]+[round(a+sgn*d,5) for a in axles for sgn in (-1,1) for d in (.0,.18,.30,.342,.36,.372,.378,.379,.386,.40,.42,.436)]))
def sidepts(x):
 w,h,s=cat(x,1),cat(x,2),cat(x,3);z=cut(x);lip=max(0, min(1,(z-.30)/.20))
 return [(w*(.91+.065*lip),z),(w*(.963+.033*lip),z+.18*(s-z)),(w*(.983+.017*lip),z+.52*(s-z)),(w*.997,s-.048),(w*.98,s),(w*.86,h-.019),(w*.58,h+.004),(w*.30,h+.014),(0,h+.018)]
def cross(x):
 p=sidepts(x)
 return [(x,-y,z) for y,z in p]+[(x,y,z) for y,z in reversed(p[:-1])]
def surface(name,rows,m,smooth=True):
 n=len(rows[0]); v=sum(rows,[]); f=[(j*n+i,j*n+i+1,(j+1)*n+i+1,(j+1)*n+i) for j in range(len(rows)-1) for i in range(n-1)]
 return obj(name,v,f,m,smooth)
# Matching winding on each face; leave the two sides open beneath the arch.
body=surface('Continuous sculpted body with open wheel cutouts',[cross(x) for x in xs],paint)
if body.data.polygons[len(body.data.polygons)//2+7].normal.z<0:
 for p in body.data.polygons:p.flip()
for x,n in [(xs[0],'Rear closing panel'),(xs[-1],'Front closing panel')]:
 pts=cross(x); o=obj(n,pts,[tuple(range(len(pts)))],paint)
 if o.data.polygons[0].normal.x*x<0:o.data.polygons[0].flip()
for sg in [-1,1]:
 rows=[]
 for x in xs:
  y,z=sidepts(x)[0]; rows.append([(x,sg*y,z),(x,sg*(y-.026),z-.012),(x,sg*(y-.12),z-.014)])
 o=surface('Fender returns and sill',rows,dark)
 if sg<0:
  for p in o.data.polygons:p.flip()
cube('Undertray',(0,0,.234),(3.62,1.21,.14),dark,.07)
# Cabin crown, a wrapped upper on a 5-door profile.
# Round the front A-pillar and hatch transitions with sampled cross-sections.
cabP=[(-1.745,.648,.905,.908),(-1.62,.736,.924,1.050),(-1.45,.759,.959,1.238),(-1.25,.748,.965,1.424),(-1.02,.735,.971,1.513),(-.79,.73,.978,1.552),(-.26,.726,.984,1.581),(.20,.715,.986,1.562),(.37,.703,.988,1.539),(.50,.688,.986,1.468),(.68,.674,.984,1.342),(.85,.652,.982,1.222),(1.005,.614,.978,1.097),(1.171,.551,.909,.911)]
def ci(x,j):
 for i in range(len(cabP)-1):
  if x<=cabP[i+1][0]:
   u,v=cabP[i],cabP[i+1];t=max(0,min(1,(x-u[0])/(v[0]-u[0])))
   return u[j]*(1-t)+v[j]*t
 return cabP[-1][j]
def cab(x):
 w,z,t=[ci(x,j) for j in (1,2,3)];h=t-z
 return [(w,z-.055),(w*.985,z+.11*h),(w*.93,z+.45*h),(w*.81,z+.83*h),(w*.72,z+.948*h),(w*.59,z+.985*h),(w*.33,t),(0,t+.014)]
def cb(x):
 p=cab(x)
 return [(x,-y,z) for y,z in p]+[(x,y,z) for y,z in reversed(p[:-1])]
o=surface('Rounded roof and continuous pillars',[cb(p[0]) for p in cabP],paint)
for p in o.data.polygons:p.flip()
def side_point(x,t,sg,offset):
 p=cab(x);z=p[0][1]+t*(p[-1][1]-p[0][1]);y=p[-1][0]
 for (a,b),(c,d) in zip(p,p[1:]):
  if z<=d:
   q=(z-b)/max(.0001,d-b);y=a+(c-a)*q;break
 return (x,sg*(y+offset),z)
def sideglass(sg,x0,x1):
 xx=sorted(set([x0,x1]+[p[0] for p in cabP if x0<p[0]<x1]+[x0+(x1-x0)*i/18 for i in range(1,18)]))
 def rows(offset,inner):
  ll=[]
  for x in xx:
   u=(x-x0)/(x1-x0); edge=abs(u*2-1)**8
   ll.append([side_point(x,t,sg,offset) for t in (.12+.04*edge+inner,.25,.45,.64,.84-.08*edge-inner)])
  return ll
 for m,d,t in [(dark,.008,0),(glass,.012,.025)]:
  o=surface('Flush side glazing and surrounding seal',rows(d,t),m)
  n=o.data.polygons[0].normal
  if n.y*sg<0:
   for p in o.data.polygons:p.flip()
for sg in [-1,1]:
 for a,b in [(-1.52,-1.09),(-1.047,-.403),(-.35,.68)]:sideglass(sg,a,b)
def crown_glass(x0,x1,n):
 xx=sorted(set([x0,x1]+[p[0] for p in cabP if x0<p[0]<x1]+[x0+(x1-x0)*i/15 for i in range(1,15)]))
 def rows(zoff,inner):
  rr=[]
  for x in xx:
   p=cab(x);u=(x-x0)/(x1-x0);w=p[4][0]*(.93-.065*abs(2*u-1)**5-inner)
   vv=[]
   for j in range(17):
    y=w*(j/8-1);ay=abs(y);z=p[-1][1]
    for (a,b),(c,d) in zip(p,p[1:]):
     if c<=ay<=a:
      z=b+(d-b)*(a-ay)/max(.0001,a-c);break
    vv.append((x,y,z+zoff))
   rr.append(vv)
  return rr
 for lo,hi,m,d,w in [(x0,x1,dark,.009,0),(x0+.022,x1-.022,glass,.016,.032)]:
  xx=sorted(set([lo,hi]+[p[0] for p in cabP if lo<p[0]<hi]+[lo+(hi-lo)*i/15 for i in range(1,15)]))
  o=surface(n,rows(d,w),m)
  if o.data.polygons[0].normal.z<0:
   for p in o.data.polygons:p.flip()
crown_glass(.383,1.036,'Raked front windshield')
crown_glass(-1.638,-1.077,'Wrap rear hatch glass')
def lathe(name,x,y,z,rows,m,n=40,annular=False):
 if annular:rows=list(rows)+[rows[0]]
 return ring(name,[[(x+r*cos(i*2*pi/n),y+d,z+r*sin(i*2*pi/n)) for i in range(n)] for d,r in rows],m,cap=not annular)
for a in axles:
 for sg in [-1,1]:
  y=sg*.737
  lathe('Recessed radial tire',a,y,ctr,[(-.113,.204),(-.112,.255),(-.104,.294),(-.083,.314),(-.062,rad),(.062,rad),(.083,.314),(.104,.294),(.112,.255),(.113,.204)],rubber,36,True)
  outer=sg*.856
  lathe('Alloy rim machined lip',a,outer,ctr,[(sg*.011,.225),(sg*.023,.212),(sg*.024,.191),(sg*.016,.186),(sg*.010,.201)],silver,36,True)
  lathe('Brake disc',a,outer-sg*.026,ctr,[(-.004,.167),(.004,.167)],polish,28)
  for k in range(10):
   u=k*pi/5
   def ss(r,v,d):return (a+r*cos(u)-v*sin(u),outer+sg*d,ctr+r*sin(u)+v*cos(u))
   vv=[ss(.053,-.024,.027),ss(.050,.012,.027),ss(.193,.022,.007),ss(.193,.006,.007),ss(.098,-.020,.020)]
   o=ring('Swept machined spoke',[vv,[(x,y-sg*.012,z) for x,y,z in vv]],silver,False)
  lathe('Machined centre cap',a,outer+sg*.025,ctr,[(sg*.011,.049),(sg*.013,.042)],chrome,22)
  for k in range(5):
   u=k*2*pi/5
   lathe('Recessed lug',a+.032*cos(u),outer+sg*.04,ctr+.032*sin(u),[(0,.006),(sg*.002,.006)],polish,8)
def interp_side(x,z,sg,off=.004):
 p=sidepts(x)
 for (a,b),(c,d) in zip(p,p[1:]):
  if b<=z<=d:return (x,sg*(a+(c-a)*(z-b)/max(.00001,d-b)+off),z)
 return (x,sg*(p[0][0]+off),z)
for sg in [-1,1]:
 for x in [-.75,.28]:
  p=interp_side(x,.806,sg,.008)
  cube('Body-colour pull handle with shadow recess',p,(.141,.019,.026),dark,.008)
  cube('Flush handle',(p[0]+.012,p[1]+sg*.009,p[2]+.003),(.105,.017,.014),paint,.005)
 for x,t in [(-.40,.18),(.47,.20)]:
  z0=cut(x)+.033;z1=cat(x,3)-.027
  line('Door shut line',[interp_side(x+t*(1-u)**3,z0+(z1-z0)*u,sg) for u in [i/16 for i in range(17)]],.0031,dark)
 line('Sill shut line',[interp_side(-.77+1.48*i/28,cut(-.77+1.48*i/28)+.03,sg) for i in range(29)],.0031,dark)
 o=cube('Mirror stalk',(.58,sg*.775,1.057),(.12,.15,.047),dark,.018);o.rotation_euler.x=sg*.20
 o=cube('Aerodynamic painted side mirror',(.588,sg*.888,1.099),(.206,.175,.101),paint,.046);o.rotation_euler.z=-sg*.17
 o=cube('Mirror glass',(.493,sg*.895,1.097),(.017,.124,.064),chrome,.008);o.rotation_euler.z=-sg*.24
# Corner lamps flow into the fenders; overlay on exterior skin, with shaped reflectors.
def body_z(x,y):
 p=sidepts(x);a=abs(y)
 for (w,z),(w1,z1) in zip(p[3:],p[4:]):
  if w1<=a<=w:return z+(z1-z)*(w-a)/max(.00001,w-w1)
 return p[-1][1]
for sg in [-1,1]:
 for front in [True,False]:
  def lamp_rows(inner,offset):
   rr=[]
   for i in range(17):
    u=(i/16-.5)*(1-inner)+.5
    x=(1.96-.50*u if front else -1.965+.405*u)
    w=cat(x,1);mid=w*(.65+.277*u)
    wide=(.107-.086*u)*sqrt(max(.001,sin(pi*u)))*(1-inner)+.009
    rr.append([(x,sg*min(w*.987,mid+v*wide),body_z(x,min(w*.987,mid+v*wide))+offset) for v in [-1,-.5,0,.5,1]])
   return rr
  for m,inn,off in [(dark,0,.010),(white if front else red,.115,.016)]:
   o=surface('Swept corner lamp',lamp_rows(inn,off),m,False)
   if o.data.polygons[0].normal.z<0:
    for p in o.data.polygons:p.flip()
  rr=lamp_rows(.32,.021)
  line('Continuous lighting signature',[p[1] for p in rr],.007,white if front else red)
 for x,m in [(1.958,white),(-1.992,red)]:
  o=cube('Corner bumper reflector',(x,sg*.594,.457),(.135,.208,.044),m,.019)
  o.rotation_euler.z=sg*(.31 if x>0 else -.20)
o=cube('Sculpted black front intake',(2.019,0,.429),(.106,1.04,.234),dark,.052)
for z in [.361,.398,.435,.472,.509]:
 cube('Grille horizontal louvre',(2.077,0,z),(.018,.913 if z<.49 else .86,.009),polish,.003)
cube('Upper grille',(2.020,0,.563),(.055,.87,.06),dark,.019)
cube('Lower rear diffuser',(-2.007,0,.36),(.103,1.19,.137),dark,.048)
for y in [-.46,-.33,.33,.46]:cube('Diffuser vane',(-2.011,y,.321),(.094,.025,.08),polish,.011)
def platef(sg,z):
 cube('Recessed number plate mount',(sg*2.067,0,z),(.033,.356,.113),dark,.019)
 cube('Number plate',(sg*2.088,0,z),(.015,.314,.079),plate,.009)
 c=bpy.data.curves.new('Northline fictitious registration','FONT');c.body='NL 207';c.align_x='CENTER';c.align_y='CENTER';c.size=.047;c.extrude=.00030
 o=bpy.data.objects.new('Fictional registration',c);car.objects.link(o);o.location=(sg*2.097,0,z)
 o.rotation_euler=(pi/2,0,sg*pi/2);o.data.materials.append(textmat)
platef(1,.543);platef(-1,.565)
# With stage excluded, the source and GLB contain only the editable vehicle.
bpy.ops.object.select_all(action='DESELECT')
for o in car.objects:o.select_set(True)
bpy.ops.export_scene.gltf(filepath=os.path.join(OUT,'Northline-5.glb'),export_format='GLB',use_selection=True,export_texcoords=False,export_tangents=False)
# Camera/light setup uses actual mesh; simple asphalt and sidewalk are studio stand-ins.
asphalt=mat('Asphalt with aggregate',(.088,.091,.094),.89)
nodes=asphalt.node_tree.nodes; links=asphalt.node_tree.links;pr=nodes.get('Principled BSDF')
tc=nodes.new('ShaderNodeTexCoord'); tex=nodes.new('ShaderNodeTexNoise');tex.inputs['Scale'].default_value=36;tex.inputs['Detail'].default_value=3.5;links.new(tc.outputs['Object'],tex.inputs['Vector'])
r=nodes.new('ShaderNodeValToRGB');r.color_ramp.elements[0].color=(.045,.048,.050,1);r.color_ramp.elements[1].color=(.121,.126,.131,1);links.new(tex.outputs['Fac'],r.inputs[0]);links.new(r.outputs[0],pr.inputs['Base Color'])
t=nodes.new('ShaderNodeBump');t.inputs['Strength'].default_value=.24;t.inputs['Distance'].default_value=.019;links.new(tex.outputs['Fac'],t.inputs['Height']);links.new(t.outputs[0],pr.inputs['Normal'])
walk=mat('Warm stone sidewalk',(.34,.32,.27),.83);mark=mat('Road marking',(.65,.65,.58),.80)
cube('Road',(0,0,-.065),(42,36,.12),asphalt,0,stage)
for i in range(-14,15):
 for j in range(4):
  cube('Pavement slab',(i*1.2,(2.95+j*.83),.054),(1.187,.817,.122),walk,.009,stage)
for i in range(-5,6):
 cube('Lane divider',(i*4.4,-2.3,.003),(2.3,.093,.005),mark,0,stage)
for i in range(7):
 cube('Crosswalk stripe',(-4.7,i*.77-2.43,.005),(.97,.36,.005),mark,.003,stage)
def area(n,at,power,size,color,tar=(0,0,.6),shape='DISK',size_y=None):
 d=bpy.data.lights.new(n,'AREA');d.energy=power;d.shape=shape;d.size=size;d.color=color
 if size_y is not None:d.size_y=size_y
 o=bpy.data.objects.new(n,d);stage.objects.link(o);o.location=at;o.rotation_euler=(Vector(tar)-o.location).to_track_quat('-Z','Y').to_euler()
area('Day sky card',(-2,0,7),1350,8,(.79,.88,1),shape='RECTANGLE',size_y=4)
area('Warm key',(4,-3,6),960,6,(1,.83,.64))
area('Long rim',(-4,4.8,3.1),840,6,(.74,.86,1),shape='RECTANGLE',size_y=2)
area('Wheel fill',(1,-5.2,2),300,4,(.81,.91,1))
sc.world=bpy.data.worlds.new('Cloudy sky');sc.world.use_nodes=True;bg=sc.world.node_tree.nodes.get('Background');bg.inputs[0].default_value=(.53,.61,.73,1);bg.inputs[1].default_value=.34
sc.render.engine='CYCLES';sc.cycles.samples=36;sc.cycles.use_denoising=False
sc.view_settings.view_transform='AgX'
sc.render.resolution_x=1000;sc.render.resolution_y=570;sc.render.resolution_percentage=100;sc.render.image_settings.file_format='PNG'
d=bpy.data.cameras.new('Review camera');c=bpy.data.objects.new('Review camera',d);stage.objects.link(c);sc.camera=c;d.lens=56
def view(name,at,target,lens):
 c.location=at;c.rotation_euler=(Vector(target)-c.location).to_track_quat('-Z','Y').to_euler();d.lens=lens
 sc.render.filepath=os.path.join(OUT,name+'.png');bpy.ops.render.render(write_still=True)
c.location=(5.4,-6.0,2.8);c.rotation_euler=(Vector((0,0,.69))-c.location).to_track_quat('-Z','Y').to_euler()
bpy.ops.wm.save_as_mainfile(filepath=os.path.join(OUT,'Northline-5.blend'))
view('northline-front',(5.4,-6.0,2.8),(0,0,.68),62)
view('northline-side',(-.15,-8.1,1.75),(0,0,.68),62)
view('northline-rear',(-5.8,5.6,2.5),(0,0,.64),59)
view('northline-overhead',(4.7,-5.9,8.5),(0,0,.50),68)
