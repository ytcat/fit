GLORY OF THE RING / CITY VEHICLE STUDIES
Original Blender source models and GLB interchange files for visual approval.
These are authoring models. Nothing here has been added to a game build.
The asphalt, studio lighting and sidewalks in review images are not game footage.

The current street traffic path is batched; do not install all these authoring meshes as moving cars. Design reduced geometry levels, retain paint-only tint and shared material batches, then measure real mobile free-walk. The one-third conversion and local +Z forward apply to the existing map geometry path, not to the authored assets as exported. Preserve wheel contact and a truthful collision envelope for different vehicle sizes. Project locales must use identical vehicles. Only the comparison copy is English.
