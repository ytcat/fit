import bpy, math, os, sys
from mathutils import Vector
from mathutils.bvhtree import BVHTree
from math import sin,cos,pi
b=bpy
b.ops.object.select_all(action='SELECT');b.ops.object.delete(use_global=False)
D=os.path.dirname(__file__)
def m(n,c,metal=.0,r=.4):
 a=b.data.materials.new(n);a.diffuse_color=(*c,1);a.use_nodes=True;p=a.node_tree.nodes.get('Principled BSDF');p.inputs['Base Color'].default_value=(*c,1);p.inputs['Metallic'].default_value=metal;p.inputs['Roughness'].default_value=r;return a
blue=m('Midnight blue mica',(.034,.105,.224),.72,.27); dark=m('Adaptive black trim',(.02,.029,.041),.28,.37); shade=m('Brake vents',(.008,.012,.016),.12,.47); chrome=m('Satin brushed alloy',(.48,.57,.65),.79,.26)
glass=m('Smoked blue panoramic glazing',(.019,.037,.054),.1,.32); lamp=m('LED Ice',(.66,.87,1),.27,.2); red=m('Ruby optics',(.53,.025,.045),.38,.24); tyre=m('Molded rubber',(.021,.024,.028),0,.65); brake=m('Rotor',(.13,.16,.19),.74,.39); cal=m('Brake caliper',(.39,.23,.076),.44,.30); plate=m('Warm enamel plate',(.8,.78,.64),.22,.42)
def mesh(n,vs,fs,ma,mi=None,smooth=True):
 me=b.data.meshes.new(n);me.from_pydata(vs,[],fs);me.update();o=b.data.objects.new(n,me);b.context.collection.objects.link(o);
 for v in ma:me.materials.append(v)
 for i,p in enumerate(me.polygons):
  p.use_smooth=smooth
  if mi:p.material_index=mi[i]
 return o
def bevel(o,w=.025,s=2):
 a=o.modifiers.new('Production radius','BEVEL');a.width=w;a.segments=s
 a=o.modifiers.new('Weighted body normals','WEIGHTED_NORMAL');a.keep_sharp=True
 return o
def box(n,p,s,ma,w=.025):
 b.ops.mesh.primitive_cube_add(size=1,location=p);o=b.context.object;o.name=n;o.dimensions=s;b.ops.object.transform_apply(location=False,rotation=False,scale=True);o.data.materials.append(ma)
 return bevel(o,w) if w else o
def ell(n,p,s,ma):
 b.ops.mesh.primitive_uv_sphere_add(segments=16,ring_count=8,location=p);o=b.context.object;o.name=n;o.scale=s;o.data.materials.append(ma)
 for q in o.data.polygons:q.use_smooth=True
 return o
def cyl(n,x,y,z,r,dep,ma):
 b.ops.mesh.primitive_cylinder_add(vertices=28,radius=r,depth=dep,location=(x,y,z),rotation=(pi/2,0,0));o=b.context.object;o.name=n;o.data.materials.append(ma)
 return bevel(o,.011,2)
def spline(n,pts,mat,r=.007):
 cu=b.data.curves.new(n,'CURVE');cu.dimensions='3D';cu.bevel_depth=r;cu.bevel_resolution=1;cu.resolution_u=1;sp=cu.splines.new('POLY');sp.points.add(len(pts)-1)
 for p,t in zip(sp.points,pts):p.co=(*t,1)
 o=b.data.objects.new(n,cu);b.context.collection.objects.link(o);cu.materials.append(mat);return o
# Width/section height across buttresses; nested cross section draws real rolled rocker/shoulder and crown.
st=[(-2.41,.72,.68,.29),(-2.32,.85,.78,.27),(-2.1,.945,.87,.27),(-1.76,.95,.94,.25),(-1.40,.941,.98,.25),(-.94,.929,1.0,.25),(-.38,.927,1.01,.25),(.23,.936,.996,.25),(.82,.953,.945,.25),(1.38,.961,.89,.25),(1.84,.945,.83,.26),(2.18,.901,.782,.27),(2.34,.802,.698,.31),(2.4,.70,.63,.36)]
def interp(a,t,j):
 p,q,r,s=a[max(j-1,0)],a[j],a[j+1],a[min(j+2,len(a)-1)]
 return tuple(q[k]+.5*t*((r[k]-p[k])+t*((2*p[k]-5*q[k]+4*r[k]-s[k])+t*(3*(q[k]-r[k])+s[k]-p[k]))) for k in range(len(q)))
def sample(a,sub):
 return [interp(a,i/sub,j) for j in range(len(a)-1) for i in range(sub)]+[a[-1]]
ring=[(.0,0),(.78,0),(.94,.06),(1,.34),(1,.59),(.972,.77),(.911,.90),(.78,.964),(.55,.989),(0,1),(-.55,.989),(-.78,.964),(-.911,.90),(-.972,.77),(-1,.59),(-1,.34),(-.94,.06),(-.78,0)]
def loft(n,rows,mat,isCab=False):
 vs=[(x,w*a,low+(h-low)*z) for x,w,h,low in rows for a,z in ring];nq=len(ring);fs=[];mi=[]
 for k in range(len(rows)-1):
  for j in range(nq):
   fs.append((k*nq+j,(k+1)*nq+j,(k+1)*nq+(j+1)%nq,k*nq+(j+1)%nq)); x=(rows[k][0]+rows[k+1][0])*.5
   glazed=(j in range(3,15) and -1.09<x<.98)
   if -.64<x<.55 and 7<=j<=10:glazed=False  # painted roof, smoked side glass
   if -.34<x<-.255 and j not in range(7,11):glazed=False  # B-pillars built into the glazing surface
   mi.append(int(isCab and glazed))
 fs += [tuple(range(nq-1,-1,-1)),tuple((len(rows)-1)*nq+j for j in range(nq))];mi += [0,0]
 ob=mesh(n,vs,fs,mat,mi)
 b.ops.object.select_all(action='DESELECT');ob.select_set(True);b.context.view_layer.objects.active=ob;b.ops.object.mode_set(mode='EDIT');b.ops.mesh.select_all(action='SELECT');b.ops.mesh.normals_make_consistent(inside=False);b.ops.object.mode_set(mode='OBJECT')
 return ob
body=loft('01 Aero-sculpted main shell',sample(st,4),[blue])
axles=[-1.44,1.43]
# Real arch cut reaches into the shell and leaves the full free wheel/ground envelope.
for x in axles:
 for s in [-1,1]:
  cut=cyl('temp arch',x,s*.82,.356,.424,.66,shade);cut.modifiers.clear()
  b.context.view_layer.objects.active=body;a=body.modifiers.new('True wheel aperture','BOOLEAN');a.operation='DIFFERENCE';a.object=cut;a.solver='EXACT';b.ops.object.modifier_apply(modifier=a.name);b.data.objects.remove(cut,do_unlink=True)
  spline('Rolled arch edge',[(x+.429*cos(t*pi/32),s*.944,.358+.429*sin(t*pi/32)) for t in range(33)],dark,.012)
roof=[(-1.48,.66,.914,.89),(-1.21,.73,1.01,.91),(-.96,.756,1.20,.93),(-.66,.752,1.405,.95),(-.37,.733,1.47,.96),(.01,.717,1.477,.96),(.30,.701,1.448,.96),(.56,.671,1.367,.95),(.84,.644,1.20,.93),(1.15,.637,.938,.90)]
cab=loft('02 Glasshouse painted frame and tinted flush windshield',sample(roof,4),[blue,glass],True)
# Paint roof bridge added flush across the dark canopy; small strip seals follow true section profile.
for s in [-1,1]:
 spline('Window belt chrome',[(x,s*w*1.003,.94+(h-.95)*.16) for x,w,h,_ in sample(roof,4)],chrome,.011)
 spline('Roof shoulder seal',[(x,s*w*.67,h-.032) for x,w,h,_ in sample(roof,4) if -.83<x<.86],dark,.013)
 for x in [-.30,.47]:
  f=min(roof,key=lambda v:abs(v[0]-x)); _,w,h,_=f
  spline('Pillar applique',[(x,s*(w+.008),1.02),(x,s*w*.964,1.13),(x-.014,s*w*.86,1.30),(x-.024,s*w*.72,h-.025)],dark,.022)
 for x in [-.81,.03,.94]:
  spline('Door shut seam',[(x-.045,s*.886,.927),(x,s*.933,.76),(x+.016,s*.945,.48),(x-.045,s*.904,.30)],dark,.004)
 for x in [-.52,.34]:box('Flush handle',(x,s*.93,.843),(.142,.022,.022),chrome,.008)
 spline('Side skirt highlight',[(x,s*.879,.31+.016*cos(x)) for x in [-.94,-.60,0,.62,.94]],chrome,.012)
 ell('Heated mirror',( .71,s*.947,1.039),(.135,.125,.071),blue);box('Mirror foot',(.66,s*.824,.989),(.075,.19,.061),dark)
# Lay the optics into the real curved sheet metal rather than floating on hand-placed coordinates.
b.context.view_layer.update()
body_bvh=BVHTree.FromObject(body,b.context.evaluated_depsgraph_get())
def focal(n,pts,mat,r):
 fit=[]
 for xyz in pts:
  loc,norm,_,_=body_bvh.find_nearest(Vector(xyz))
  fit.append(tuple(loc+norm*.004))
 return spline(n,fit,mat,r)
# Daylight graphics and fitted lamps. Positive longitudinal end is nose.
for s in [-1,1]:
 focal('White L-shaped DRL',[(2.358,s*.70,.665),(2.275,s*.805,.731),(2.12,s*.875,.78),(1.98,s*.921,.797)],lamp,.022)
 focal('Headlamp black aperture',[(2.346,s*.657,.644),(2.249,s*.786,.699),(2.09,s*.868,.741),(2.0,s*.905,.762)],dark,.030)
 focal('Ruby rear signature',[(-2.409,s*.25,.648),(-2.397,s*.48,.650),(-2.356,s*.69,.696),(-2.27,s*.817,.741),(-2.11,s*.90,.765)],red,.027)
 box('Front corner intake',(2.27,s*.64,.426),(.12,.30,.135),shade,.029)
 box('Rear silver exhaust insert',(-2.337,s*.59,.348),(.13,.22,.065),chrome,.026)
box('Low front intake',(2.353,0,.442),(.113,.91,.198),dark,.047)
for k in range(4):
 spline('Front intake louvre',[(2.415,-.39,.43+.037*k),(2.426,0,.431+.037*k),(2.415,.39,.43+.037*k)],chrome,.005)
spline('Full-width rear smoked insert',[(-2.422,-.45,.648),(-2.429,0,.647),(-2.422,.45,.648)],dark,.026)
box('Rear license plate',(-2.434,0,.482),(.024,.275,.093),plate,.009)
box('Front license plate',(2.435,0,.409),(.022,.236,.072),plate,.007)
ell('Hood insignia',(2.22,0,.785),(.041,.038,.009),chrome)
# Radial tyre and machined wheel with inset spokes; no overlapping solid rim disc.
def revol(n,x,y,z,sec,ma):
 V=[];F=[];N=36
 for r,t in sec:
  V += [(x+r*cos(i*2*pi/N),y+t,z+r*sin(i*2*pi/N)) for i in range(N)]
 for k in range(len(sec)):
  q=(k+1)%len(sec)
  F.extend((k*N+i,k*N+(i+1)%N,q*N+(i+1)%N,q*N+i) for i in range(N))
 return mesh(n,V,F,[ma])
for x in axles:
 for s in [-1,1]:
  y=s*.878;z=.354
  created=set(b.context.scene.objects)
  revol('Road tyre real section',x,y,z,[(.258,-.105),(.309,-.115),(.341,-.087),(.355,-.048),(.355,.048),(.341,.087),(.309,.115),(.258,.105)],tyre)
  revol('Brushed wheel lip',x,y,z,[(.219,s*.108),(.251,s*.111),(.260,s*.106),(.259,s*.088),(.226,s*.09)],chrome)
  cyl('Ventilated brake disc',x,y+s*.042,z,.200,.036,brake)
  ell('Visible caliper',(x+.16,y+s*.069,z+.051),(.037,.03,.077),cal)
  cyl('Alloy hub',x,y+s*.095,z,.073,.033,chrome);cyl('Centre cap',x,y+s*.116,z,.036,.018,dark)
  for k in range(10):
   a=k*2*pi/10; c=cos(a);t=sin(a); o=box('Turbine alloy spoke',(x+c*.143,y+s*.102,z+t*.143),(.206,.026,.027),chrome,.008);o.rotation_euler.y=-a+.19
  for q in [-.044,0,.044]:
   revol('Tyre fine circumferential tread',x,y+q,z,[(.354,-.003),(.355,-.002),(.355,.002),(.354,.003)],shade)
  tag=('Front' if x>0 else 'Rear')+('_left' if s<0 else '_right')+'_wheel'
  for o in set(b.context.scene.objects)-created:o['sedanWheel']=tag
# Export X-longitudinal as existing city cars; Blender exporter uses standard +Y up.
b.context.preferences.filepaths.save_version=0
b.ops.wm.save_as_mainfile(filepath=D+'/gloryland-midnight-sedan.blend')
def combine(objects,name,origin=None):
 b.ops.object.select_all(action='DESELECT')
 for o in objects:o.select_set(True)
 b.context.view_layer.objects.active=objects[0]
 b.ops.object.convert(target='MESH')
 b.ops.object.join()
 ob=b.context.object;ob.name=name
 if origin:
  b.context.scene.cursor.location=origin
  b.ops.object.origin_set(type='ORIGIN_CURSOR')
 return ob
for x in axles:
 for side in [-1,1]:
  tag=('Front' if x>0 else 'Rear')+('_left' if side<0 else '_right')+'_wheel'
  combine([o for o in b.context.scene.objects if o.get('sedanWheel')==tag],tag,(x,side*.878,.354))
combine([o for o in b.context.scene.objects if not o.get('sedanWheel')],'Midnight sedan coachwork')
b.ops.object.select_all(action='SELECT');b.ops.export_scene.gltf(filepath=D+'/gloryland-midnight-sedan.glb',export_format='GLB',use_selection=True,export_yup=True)

scene=b.context.scene;scene.render.engine='CYCLES';scene.cycles.samples=64;scene.cycles.use_denoising=False;scene.render.resolution_x=650;scene.render.resolution_y=465;scene.render.resolution_percentage=100
scene.world.color=(.16,.21,.29)
plane=box('Studio cyclorama',(0,0,-.105),(200,200,.16),m('Backdrop',(.16,.20,.26),.05,.46),0)
def light(n,p,w,h,energy,target=(0,0,.65)):
 b.ops.object.light_add(type='AREA',location=p);o=b.context.object;o.name=n;o.data.energy=energy;o.data.shape='RECTANGLE';o.data.size=w;o.data.size_y=h;o.rotation_euler=(Vector(target)-o.location).to_track_quat('-Z','Y').to_euler()
light('Key strip',(2,-4,7),5,3,870);light('Side strip',(-1,4,5),7,2.4,1200);light('Head strip',(6,1,3),3,3,540);light('Lift',(-5,-2,3),3,4,650)
b.ops.object.camera_add();cam=b.context.object;scene.camera=cam;cam.data.type='ORTHO';cam.data.ortho_scale=5.9
for name,p in [('front',(6,-4.7,2.6)),('profile',(.03,-7.9,1.78)),('rear',(-6,-4.7,2.60))]:
 cam.location=p;cam.rotation_euler=(Vector((0,0,.67))-cam.location).to_track_quat('-Z','Y').to_euler();scene.render.filepath=D+'/'+name+'.png';b.ops.render.render(write_still=True)
