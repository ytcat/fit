const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),a=require('node:assert/strict');
global.window=global;global.self=global;
const vendor=process.argv[3]||path.join(__dirname,'../base/assets/vendor');
global.THREE=require(path.join(vendor,'three.min.js'));
vm.runInThisContext(fs.readFileSync(path.join(vendor,'GLTFLoader.js'),'utf8'));
const data=fs.readFileSync(process.argv[2]||path.join(__dirname,'Midnight-Pier-Wheel.glb'));
(async()=>{
 const g=await new Promise((yes,no)=>new THREE.GLTFLoader().parse(data.buffer.slice(data.byteOffset,data.byteOffset+data.length),'./',yes,no));
 a.equal(g.animations.length,1);
 const mixer=new THREE.AnimationMixer(g.scene);mixer.clipAction(g.animations[0]).play();
 const cars=[];let rotor,stand;
 g.scene.traverse(o=>{if(/^Gondola_?\d/.test(o.name))cars.push(o);if(o.name.startsWith('02_Rotor'))rotor=o;if(o.name.startsWith('01_Fixed'))stand=o;});
 a.equal(cars.length,16);a(rotor&&stand);
 const home=cars[0].getWorldPosition(new THREE.Vector3());
 const startQ=stand.getWorldQuaternion(new THREE.Quaternion());
 for(const t of [0,.25,2.5,6,9.1,12,15,18,21.65,23.95]){
  mixer.setTime(t);g.scene.updateMatrixWorld(true);
  for(const car of cars){
   const q=car.getWorldQuaternion(new THREE.Quaternion());
   const y=new THREE.Vector3(0,1,0).applyQuaternion(q);
   a(y.y>.99985,'A gondola must stay upright');
   const p=car.getWorldPosition(new THREE.Vector3());
   a(Math.abs(Math.hypot(p.x,p.y-10.4)-7.6)<.0001,'Cabin pin stays on ring');
  }
  a(stand.getWorldQuaternion(new THREE.Quaternion()).angleTo(startQ)<.0001);
 }
 mixer.setTime(6);g.scene.updateMatrixWorld(true);
 a(cars[0].getWorldPosition(new THREE.Vector3()).distanceTo(home)>8);
 console.log('Three r'+THREE.REVISION+': 16 cabins orbit and stay upright, bearings and platform are fixed; one '+g.animations[0].duration.toFixed(2)+' second animation clip.');
})().catch(e=>{console.error(e);process.exitCode=1;});
