"""Combine the per-node Blender glTF actions into one synchronized review loop."""
import json, struct, sys, pathlib
p=pathlib.Path(sys.argv[1]); data=p.read_bytes(); hdr=b'glTF'
json_len,kind=struct.unpack_from('<I4s',data,12); assert kind==b'JSON'
g=json.loads(data[20:20+json_len]); suffix=data[20+json_len:]
samplers=[];channels=[]
for clip in g['animations']:
    k=len(samplers); samplers.extend(clip['samplers'])
    channels.extend({**ch,'sampler':ch['sampler']+k} for ch in clip['channels'])
g['animations']=[{'name':'Midnight Pier - revolution loop','channels':channels,'samplers':samplers}]
j=json.dumps(g,separators=(',',':')).encode();j+=b' '*((-len(j))%4)
p.write_bytes(struct.pack('<4sII',hdr,2,20+len(j)+len(suffix))+struct.pack('<I4s',len(j),b'JSON')+j+suffix)
