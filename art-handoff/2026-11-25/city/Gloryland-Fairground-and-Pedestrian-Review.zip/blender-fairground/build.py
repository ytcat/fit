import bpy,os,math,random
from math import sin,cos,pi
from mathutils import Vector
from collections import defaultdict
D=os.path.dirname(os.path.abspath(__file__))
bpy.ops.wm.read_factory_settings(use_empty=True)
sc=bpy.context.scene
asset=bpy.data.collections.new('Midnight Pier Wheel | design master');sc.collection.children.link(asset)
stage=bpy.data.collections.new('Review lighting and surroundings');sc.collection.children.link(stage)
def mat(name,h,r=.55,m=0,e=0,alpha=1):
 rgb=tuple(((x/255+.055)/1.055)**2.4 if x>10 else x/3294.6 for x in bytes.fromhex(h))
 k=bpy.data.materials.new(name);k.diffuse_color=(*rgb,alpha);k.use_nodes=True
 n=k.node_tree.nodes.get('Principled BSDF');n.inputs['Base Color'].default_value=(*rgb,1);n.inputs['Roughness'].default_value=r;n.inputs['Metallic'].default_value=m
 n.inputs['Emission Color'].default_value=(*rgb,1);n.inputs['Emission Strength'].default_value=e;n.inputs['Alpha'].default_value=alpha
 if alpha<1:k.surface_render_method='BLENDED'
 return k
iv=mat('Ivory powder-coated truss','C4CCD0',.45,.25); navy=mat('Petrol powder-coated steel','163743',.35,.42);steel=mat('Brushed joints','80919D',.34,.65);dark=mat('Black rubber & shadow joints','15252D',.72); brass=mat('Painted ochre','CEA35D',.44,.32); warm=mat('Warm bulbs','FFD69A',.29,0,1.3); cyan=mat('Pale turquoise bulbs','8EE9F1',.34,0,.95); interior=mat('Cabin cushions','662C31',.71); glass=mat('Tinted safety glazing','89BCD0',.26,.08,0,.27); concrete=mat('Concrete','63656A',.88); deckmat=mat('Anti-slip deck','514A42',.9); ground=mat('Dusk asphalt','29343E',.83); lampred=mat('Marker light','FF7251',.4,0,.9)
cp=[mat(n,c,.36,.30) for n,c in [('Petrol enamel','297E88'),('Crimson enamel','953F51'),('Ochre enamel','B7813F'),('Deep blue enamel','455A87')]]
def move(o,coll): 
 for c in list(o.users_collection):c.objects.unlink(o)
 coll.objects.link(o);return o
def raw(name,v,f,material,coll=asset):
 me=bpy.data.meshes.new(name);me.from_pydata(v,[],f);me.update();o=bpy.data.objects.new(name,me);coll.objects.link(o);me.materials.append(material);return o
def smooth(o):
 for p in o.data.polygons:p.use_smooth=True
 return o
def bevel(o,w,s=2):
 if not w:return o
 b=o.modifiers.new('Soft painted edges','BEVEL');b.width=w;b.segments=s
 n=o.modifiers.new('Face-weighted normals','WEIGHTED_NORMAL')
 return o
def box(n,p,size,ma,w=0,coll=asset):
 x,y,z=[a/2 for a in size]
 o=raw(n,[(-x,-y,-z),(x,-y,-z),(x,y,-z),(-x,y,-z),(-x,-y,z),(x,-y,z),(x,y,z),(-x,y,z)],[(0,3,2,1),(4,5,6,7),(0,1,5,4),(1,2,6,5),(2,3,7,6),(3,0,4,7)],ma,coll);o.location=p
 return bevel(o,w)
def pipe(n,p,q,r,ma,N=8,coll=asset):
 a,b=Vector(p),Vector(q); dz=(b-a).normalized(); dx=dz.cross(Vector((0,0,1)))
 if dx.length<.01:dx=dz.cross(Vector((0,1,0)))
 dx.normalize();dy=dz.cross(dx)
 verts=[tuple(o+r*(cos(i*2*pi/N)*dx+sin(i*2*pi/N)*dy)) for o in (a,b) for i in range(N)]
 faces=[tuple(range(N-1,-1,-1)),tuple(range(N,2*N))]+[(i,(i+1)%N,(i+1)%N+N,i+N) for i in range(N)]
 return smooth(raw(n,verts,faces,ma,coll))
def ring(n,R,z,y,r,ma,quality=112):
 v=[]
 for i in range(quality):
  a=i*2*pi/quality
  for j in range(8):
   t=j*pi/4;v.append(((R+r*cos(t))*cos(a),y+r*sin(t),z+(R+r*cos(t))*sin(a)))
 f=[(i*8+j,((i+1)%quality)*8+j,((i+1)%quality)*8+(j+1)%8,i*8+(j+1)%8) for i in range(quality) for j in range(8)]
 # Ensure outward normal before smoothing.
 o=smooth(raw(n,v,f,ma))
 from mathutils import Vector
 if o.data.polygons[0].normal.dot(Vector((1,0,0)))<0:
  for p in o.data.polygons:p.flip()
 return o
def octrow(w,d,z,k):
 return [(-w+k,-d,z),(w-k,-d,z),(w,-d+k,z),(w,d-k,z),(w-k,d,z),(-w+k,d,z),(-w,d-k,z),(-w,-d+k,z)]
def loft(n,rows,ma):
 v=[p for row in rows for p in row];f=[tuple(range(7,-1,-1)),tuple(range(len(v)-8,len(v)))]
 for j in range(len(rows)-1):
  for i in range(8):
   a=j*8+i;b=j*8+(i+1)%8;f.append((a,b,b+8,a+8))
 return bevel(raw(n,v,f,ma),.018)
def root(n,p=(0,0,0)):
 o=bpy.data.objects.new(n,None);asset.objects.link(o);o.location=p;return o
def batch(objects,owner,offset=(0,0,0)):
 # Bake static parts together by material; keep transforms of rotor and gondolas separate.
 mats=defaultdict(lambda:([],[]));dg=bpy.context.evaluated_depsgraph_get();o0=Vector(offset)
 for o in objects:
  e=o.evaluated_get(dg);mesh=e.to_mesh();mesh.calc_loop_triangles();ma=o.data.materials[0];verts,faces=mats[ma];base=len(verts)
  verts.extend(tuple(o.matrix_world@p.co-o0) for p in mesh.vertices)
  faces.extend(tuple(i+base for i in f.vertices) for f in mesh.loop_triangles);e.to_mesh_clear()
 for o in objects:bpy.data.objects.remove(o,do_unlink=True)
 for ma,(v,f) in mats.items():
  o=smooth(raw(owner.name+' • '+ma.name,v,f,ma));o.parent=owner
def snapshot():return set(asset.objects)
def new(prev):bpy.context.view_layer.update();return [o for o in asset.objects if o.type=='MESH' and o not in prev]
H=10.4;R=7.6;n=16
stand=root('01 Fixed support and boarding platform');rotor=root('02 Rotor • axle height 10.4 m',(0,0,H))
p=snapshot()
box('Island foundation',(0,0,.21),(8.8,6.6,.42),concrete,.10);box('Steel boarding deck',(0,-.70,.60),(7.4,3.25,.36),deckmat,.06)
for i in range(4):
 box('Stair step',(0,-2.68-i*.28,.72-i*.14),(2.15,.44,.17),navy,.025)
 for x in [-1.06,1.06]:box('Stair anti-slip edge',(x,-2.7-i*.28,.82-i*.14),(.20,.19,.031),brass,.01)
for y in [-1.21,1.21]:
 for x in [-3.85,3.85]:
  box('Anchor concrete foot',(x,y,.58),(1.42,1.42,.55),concrete,.075)
  pipe('Box steel A-frame upright',(x,y,.81),(0,y*.71,H),.30,navy,8)
  pipe('Support accent strip',(x,y-.29,.96),(0,y*.71-.27,H-.25),.055,brass,6)
  for s in [-1,1]:
   pipe('Anchor bolt',(x+s*.46,y-.36,.86),(x+s*.46,y-.36,.95),.076,steel,6)
 pipe('A-frame cross-tie',(-2.17,y*.90,4.42),(2.17,y*.90,4.42),.146,iv)
 pipe('Diagonal tie',(-2.2,y*.90,4.42),(1.14,y*.81,7.72),.092,steel)
for x in [-3.36,-2.4,-1.35,1.35,2.4,3.36]:
 pipe('Platform post',(x,-2.28,.76),(x,-2.28,1.91),.042,steel,8)
for x0,x1 in [(-3.43,-1.31),(1.31,3.43)]:
 for z in [1.11,1.5,1.91]:pipe('Platform safety railing',(x0,-2.28,z),(x1,-2.28,z),.036,steel,8)
for x in [-1.15,1.15]:
 for i in range(3):pipe('Step rail post',(x,-2.37-i*.39,.76-i*.17),(x,-2.37-i*.39,1.83-i*.18),.042,steel,8)
 pipe('Step handrail',(x,-2.33,1.88),(x,-3.53,1.31),.055,brass,8)
pipe('Stationary central axle',(0,-1.85,H),(0,1.85,H),.29,steel,24)
for s in [-1,1]:
 pipe('Bearing plate',(0,s*.91,H),(0,s*1.18,H),.63,navy,24)
 for i in range(8):
  a=i*pi/4; x=.48*cos(a);z=H+.48*sin(a);pipe('Bearing bolt',(x,s*1.17,z),(x,s*1.23,z),.056,brass,6)
batch(new(p),stand)
p=snapshot()
for y in [-.58,.58]:
 ring('Rolled primary hoop',R,H,y,.118,iv)
 ring('Inner structural track',R-.51,H,y,.079,navy)
 ring('Bulb conduit',R+.055,H,y+(.115 if y>0 else -.115),.037,brass)
 pipe('Rotating steel flange',(0,y-.19,H),(0,y+.19,H),.91,iv,24)
 for i in range(64):
  a=i*pi/32;y0=y+(.16 if y>0 else -.16)
  pipe('Rim lamp',(R*cos(a),y0,H+R*sin(a)),((R+.02)*cos(a),y0+(.038 if y>0 else -.038),H+(R+.02)*sin(a)),.063,cyan if i%4==0 else warm,8)
for i in range(n):
 a=i*2*pi/n;b=a+2*pi/n
 start=(R*cos(a),0,H+R*sin(a))
 pipe('Gondola hanger pin',(start[0],-.67,start[2]),(start[0],.67,start[2]),.082,brass,12)
 for y in [-.58,.58]:
  aa=a+.10;bb=a-.09
  pipe('Tapered primary spoke',(.79*cos(aa),y,H+.79*sin(aa)),(R*cos(a),y,H+R*sin(a)),.059,iv)
  pipe('Counter-tension spoke',(.85*cos(bb),y,H+.85*sin(bb)),((R-.5)*cos(b),y,H+(R-.5)*sin(b)),.041,steel)
  pipe('Diag rim brace',(R*cos(a),y,H+R*sin(a)),((R-.51)*cos(a+.20),y,H+(R-.51)*sin(a+.20)),.042,iv)
  pipe('Spoke accent',(3.58*cos(a),y,H+3.58*sin(a)),(4.92*cos(a),y,H+4.92*sin(a)),.037,cyan,8)
 pipe('Hoop lateral brace',((R-.51)*cos(a),-.58,H+(R-.51)*sin(a)),((R-.51)*cos(a+.13),.58,H+(R-.51)*sin(a+.13)),.046,iv)
batch(new(p),rotor,(0,0,H))
def cabin(ma):
 loft('Rounded stamped gondola shell',[octrow(.61,.49,-1.80,.18),octrow(.73,.56,-1.68,.18),octrow(.81,.61,-1.25,.16),octrow(.82,.61,-1.18,.16)],ma)
 loft('Roof painted eave',[octrow(.85,.65,-.47,.21),octrow(.79,.60,-.34,.22),octrow(.62,.47,-.22,.19),octrow(.46,.36,-.185,.14)],ma)
 for x in [-.61,.61]:
  for y in [-.51,.51]:pipe('Raked glazed corner post',(x*1.17,y,-1.29),(x,y*.92,-.43),.038,iv,8)
 for y in [-.512,.512]:
  box('Glazed picture panel',(0,y,-.85),(1.39,.026,.77),glass,.018)
  pipe('Picture window aluminum sash',(-.72,y,-1.22),(.72,y,-1.22),.031,brass,8)
  pipe('Gondola LED marker',(-.47,y*1.202,-1.35),(.47,y*1.202,-1.35),.026,warm,8)
  for x in [-.47,.47]:box('Vent plate',(x,y*1.195,-1.57),(.23,.024,.082),dark,.025)
 for s in [-1,1]:
  box('Curved side glazing',(s*.736,0,-.82),(.032,.83,.76),glass,.014)
  pipe('Glazed door stile',(s*.78,0,-1.53),(s*.68,0,-.43),.026,iv)
  pipe('Door reveal',(s*.804,0,-1.57),(s*.815,0,-1.18),.011,dark,8)
  pipe('Exterior handle',(s*.832,.12,-1.33),(s*.832,.30,-1.33),.022,steel,8)
  box('Individual bench',(s*.41,0,-1.40),(.32,.74,.125),interior,.044)
  box('Bench backrest',(s*.6,0,-1.22),(.10,.72,.34),interior,.04)
 for side in [-1,1]:pipe('Hanger crescent',(side*.48,0,-.25),(side*.18,0,-.04),.053,iv,12)
 pipe('Cabin hinge housing',(0,-.18,0),(0,.18,0),.127,steel,16)
 return
# One master per livery, data linked by material across the four identical colored cabins.
protos=[]
for ma in cp:
  owner=root('Cabin material prototype');p=snapshot();cabin(ma);batch(new(p),owner);protos.append(owner)
cabins=[]
for i in range(n):
 a=i*2*pi/n; owner=root('Gondola %02d'%(i+1),(R*cos(a),0,R*sin(a)));owner.parent=rotor;cabins.append(owner)
 for src in protos[i%len(protos)].children:
  clone=src.copy();asset.objects.link(clone);clone.parent=owner
for proto in protos:
 for obj in list(proto.children):bpy.data.objects.remove(obj,do_unlink=True)
 bpy.data.objects.remove(proto,do_unlink=True)
# Cubic default interpolation is disabled so the wheel turns at constant speed.
sc.render.fps=24;sc.frame_start=1;sc.frame_end=577
for f in range(1,578,144):
 t=(f-1)*2*pi/576
 rotor.rotation_euler.y=-t;rotor.keyframe_insert(data_path='rotation_euler',frame=f,index=1)
 for cb in cabins:cb.rotation_euler.y=t;cb.keyframe_insert(data_path='rotation_euler',frame=f,index=1)
for o in [rotor,*cabins]:
 for fc in o.animation_data.action.fcurves:
  for kp in fc.keyframe_points:kp.interpolation='LINEAR'
sc.frame_set(1)
bpy.ops.object.select_all(action='DESELECT')
for o in asset.objects:o.select_set(True)
bpy.ops.export_scene.gltf(filepath=os.path.join(D,'Midnight-Pier-Wheel.glb'),export_format='GLB',use_selection=True,export_texcoords=False,export_tangents=False,export_animation_mode='SCENE',export_animations=True)
# A simple theatrical street set for judging the asset at night; it is not shipped in the GLB.
box('Boardwalk paving',(0,0,-.13),(110,70,.25),ground,0,stage)
for i in range(-9,10):
 box('Boardwalk joint',(i*.87,-7,.014),(.024,6,.015),dark,0,stage)
for i in range(-5,6):
 box('Waterfront curb',(i*3.4,4.40,.09),(3.37,.34,.17),concrete,.025,stage)
for x in [-10,10]:
 pipe('Boardwalk pole',(x,-2.7,0),(x,-2.7,4.9),.11,navy,10,stage);pipe('Lamp head',(x,-2.7,4.94),(x,-2.7,5.09),.27,warm,14,stage)
def area(name,p,power,sz,col,at):
 d=bpy.data.lights.new(name,'AREA');d.energy=power;d.shape='DISK';d.size=sz;d.color=col
 o=bpy.data.objects.new(name,d);stage.objects.link(o);o.location=p;o.rotation_euler=(Vector(at)-o.location).to_track_quat('-Z','Y').to_euler()
area('Blue dusk',(-10,8,25),3900,17,(.63,.77,1),(0,0,H))
area('Warm midway key',(2,-15,17),5100,14,(1,.76,.51),(0,0,H))
area('Ground level cabin fill',(8,-8,6),1200,9,(.52,.85,1),(0,0,6))
area('Boardwalk bounce',(-8,-13,3),580,5,(1,.68,.39),(0,0,3))
sc.world=bpy.data.worlds.new('Dusk harbor');sc.world.use_nodes=True;bg=sc.world.node_tree.nodes.get('Background');bg.inputs[0].default_value=(.12,.18,.29,1);bg.inputs[1].default_value=.32
sc.render.engine='CYCLES';sc.cycles.samples=56;sc.cycles.use_denoising=False;sc.render.threads_mode='FIXED';sc.render.threads=4
sc.view_settings.view_transform='AgX';sc.render.resolution_x=710;sc.render.resolution_y=660;sc.render.resolution_percentage=100;sc.render.image_settings.file_format='PNG'
camdata=bpy.data.cameras.new('Review camera');cam=bpy.data.objects.new('Review camera',camdata);stage.objects.link(cam);sc.camera=cam
def aim(at,target,lens):
 cam.location=at;cam.rotation_euler=(Vector(target)-cam.location).to_track_quat('-Z','Y').to_euler();camdata.lens=lens
def shoot(name,at,target,lens):
 aim(at,target,lens);sc.render.filepath=os.path.join(D,name+'.png');bpy.ops.render.render(write_still=True)
aim((14,-29,10),(0,0,9.1),49)
bpy.ops.wm.save_as_mainfile(filepath=os.path.join(D,'Midnight-Pier-Wheel.blend'))
shoot('01-front',(14,-29,10),(0,0,9.1),49)
shoot('02-side',(-22,-14,9),(0,0,9.1),39)
shoot('03-back',(-12,29,10),(0,0,9.1),48)
for ch in rotor.children:
 if ch.type=='MESH':ch.hide_render=True
for cb in cabins[1:]:
 for ch in cb.children:ch.hide_render=True
for ch in stand.children:ch.hide_render=True
shoot('04-cabin',(10.6,-5.1,11.25),(7.60,0,9.55),82)
