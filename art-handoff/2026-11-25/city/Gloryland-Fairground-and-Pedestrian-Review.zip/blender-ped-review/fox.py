import bpy as b, os, math
from mathutils import Vector
from math import pi,cos,sin
D=os.path.dirname(__file__)
b.ops.object.select_all(action='SELECT');b.ops.object.delete(use_global=False)
def mat(n,c,r=.52,metal=0):
 m=b.data.materials.new(n);m.diffuse_color=(*c,1);m.use_nodes=True;p=m.node_tree.nodes.get('Principled BSDF');p.inputs['Base Color'].default_value=(*c,1);p.inputs['Roughness'].default_value=r;p.inputs['Metallic'].default_value=metal;return m
fur=mat('Burnished fox russet',(.43,.101,.035));soft=mat('Warm underside',(.72,.51,.33));brown=mat('Deep chocolate paws',(.096,.037,.022));inner=mat('Copper ear inset',(.37,.156,.107));dark=mat('Soft black',(.018,.014,.014),.36);amber=mat('Amber iris',(.62,.335,.09),.24);eye=mat('Warm off-white',(.92,.85,.68),.26)
coat=mat('Sage waxed canvas',(.085,.175,.142));cseam=mat('Raised sage stitching',(.145,.248,.198),.62);rim=mat('Dark edge binding',(.046,.102,.074));shirt=mat('Ecru rib knit',(.54,.43,.31));pants=mat('Slate wool twill',(.085,.106,.131),.72);shoe=mat('Oxblood polished leather',(.112,.047,.045),.31);sole=mat('Black rubber welt',(.049,.035,.032));metal=mat('Brushed brass hardware',(.49,.30,.117),.32,.57);bag=mat('Cognac crossbody leather',(.26,.100,.042))
def mesh(n,vs,fs,mats,ids=None,sub=1):
 me=b.data.meshes.new(n);me.from_pydata(vs,[],fs);me.update();ob=b.data.objects.new(n,me);b.context.collection.objects.link(ob)
 for m in mats:me.materials.append(m)
 for i,p in enumerate(me.polygons):
  p.use_smooth=True
  if ids:p.material_index=ids[i]
 if sub: ob.modifiers.new('Rounded continuous form','SUBSURF').levels=sub
 return ob
def loft(n,rows,mats,N=24,color=None,sub=1):
 vs=[(x+a*cos(i*2*pi/N),y+c*sin(i*2*pi/N),z) for x,y,z,a,c in rows for i in range(N)];fs=[];mi=[]
 for k in range(len(rows)-1):
  for i in range(N):
   j=(i+1)%N;fs.append((k*N+i,k*N+j,(k+1)*N+j,(k+1)*N+i));mi.append(color(k,i) if color else 0)
 fs.extend([tuple(range(N-1,-1,-1)),tuple(range((len(rows)-1)*N,len(rows)*N))]);mi.extend([0,0])
 return mesh(n,vs,fs,mats,mi,sub)
def ell(n,p,sc,m,seg=20):
 b.ops.mesh.primitive_uv_sphere_add(segments=seg,ring_count=12,location=p);o=b.context.object;o.name=n;o.scale=sc;o.data.materials.append(m)
 for f in o.data.polygons:f.use_smooth=True
 return o
def line(n,pts,m,r=.003):
 c=b.data.curves.new(n,'CURVE');c.dimensions='3D';c.resolution_u=8;c.bevel_depth=r;c.bevel_resolution=1
 s=c.splines.new('BEZIER');s.bezier_points.add(len(pts)-1)
 for p,co in zip(s.bezier_points,pts):p.co=co;p.handle_left_type='AUTO';p.handle_right_type='AUTO'
 o=b.data.objects.new(n,c);b.context.collection.objects.link(o);c.materials.append(m);return o
def block(n,p,sz,m,w=.012):
 b.ops.mesh.primitive_cube_add(size=1,location=p);o=b.context.object;o.name=n;o.dimensions=sz;b.ops.object.transform_apply(location=False,rotation=False,scale=True);o.data.materials.append(m)
 mod=o.modifiers.new('Rolled leather seams','BEVEL');mod.width=w;mod.segments=3;o.modifiers.new('Weighted normals','WEIGHTED_NORMAL');return o
# +Y forward. Fitted knit torso, a tailored long coat left open using material and geometry at lapels.
torso=[(0,0,.928,.187,.114),(0,0,.945,.198,.124),(0,0,.99,.207,.131),(0,0,1.08,.177,.112),(0,0,1.18,.167,.108),(0,0,1.29,.198,.129),(0,0,1.40,.208,.110),(0,0,1.45,.149,.089),(0,0,1.48,.083,.066)]
loft('Structured open field coat',torso,[coat,shirt],32,lambda k,i: int(i in range(6,10)))
for s in [-1,1]:
 line('Folded lapel edge',[(s*.076,.064,1.466),(s*.119,.096,1.42),(s*.096,.116,1.363),(s*.066,.126,1.25),(s*.067,.113,1.08),(s*.075,.124,.948)],cseam,.006)
 line('Utility pocket piping',[(s*.113,.107,1.072),(s*.157,.084,1.078),(s*.183,.066,1.098)],cseam,.0035)
 line('Shoulder princess seam',[(s*.128,-.091,1.42),(s*.080,-.124,1.30),(s*.091,-.110,1.13),(s*.109,-.123,.98)],cseam,.0024)
 for z in [1.04,1.14,1.24]:ell('Coat brass snap',(s*.078,.118,z),(.008,.003,.008),metal,12)
line('Stitched coat hem',[(-.173,.050,.947),(-.12,.100,.944),(0,.117,.942),(.12,.100,.944),(.173,.050,.947)],rim,.003)
loft('Raised merino collar',[(0,0,1.42,.10,.075),(0,0,1.49,.083,.064),(0,0,1.535,.066,.057)], [shirt])
loft('Neck',[(0,0,1.46,.067,.06),(0,.006,1.56,.068,.066),(0,.012,1.61,.07,.073)],[fur])
# Four fingers remain small and connected at the joint; relaxed, non-clawed gloves.
for s in [-1,1]:
 dx=s*.245
 rows=[(s*.280,.026,1.000,.049,.047),(s*.276,.021,1.055,.056,.053),(s*.272,.006,1.115,.059,.058),(s*.255,-.009,1.205,.063,.060),(s*.225,.000,1.299,.079,.072),(s*.186,0,1.394,.078,.074),(s*.174,0,1.423,.055,.058)]
 loft('Contoured set-in sleeve',rows,[coat,rim],24,lambda k,i:int(k==0))
 line('Tailored sleeve seam',[(s*.273,-.025,1.055),(s*.277,-.045,1.153),(s*.262,-.057,1.25),(s*.228,-.066,1.34)],cseam,.0025)
 ell('Relaxed palm',(s*.278,.022,.973),(.040,.033,.062),brown)
 for i in range(4):
  x=s*(.248+.018*i);ell('Separate natural finger',(x,.026,.930+abs(i-1.5)*.009),(.0125,.014,.038 if i in [1,2] else .030),brown,12)
 ell('Folded thumb',(s*.243,.054,.970),(.017,.024,.032),brown,14)
# Tailored slim-straight slacks and fitted leather ankle boots.
for s in [-1,1]:
 x=s*.106
 loft('Wool trouser leg',[(x,.003,.164,.071,.062),(x,0,.226,.075,.064),(x,.008,.410,.075,.071),(x,.021,.548,.083,.074),(x,.014,.666,.099,.084),(x,0,.796,.105,.103),(s*.091,-.005,.912,.111,.112),(s*.083,0,.979,.100,.099)],[pants])
 line('Pressed front trouser crease',[(x,.069,.23),(x,.078,.40),(x,.092,.55),(x,.094,.66),(x,.100,.80)],mat('Pressed wool edge '+str(s),(.105,.128,.153)),.002)
 loft('Rounded leather ankle boot',[(x,.065,.011,.084,.163),(x,.065,.029,.084,.163),(x,.064,.043,.083,.160),(x,.063,.078,.082,.151),(x,.035,.123,.073,.109),(x,.003,.156,.072,.070),(x,0,.207,.072,.063),(x,0,.229,.071,.061)],[shoe,sole],28,lambda k,i:int(k<2))
 line('Boot toe panel',[(x-.067,.134,.076),(x-.04,.151,.102),(x,.157,.108),(x+.04,.151,.102),(x+.067,.134,.076)],sole,.0024)
 for j in range(3):line('Fine leather laces',[(x-.032,.08+j*.014,.139-j*.007),(x+.031,.088+j*.014,.136-j*.007)],metal,.0026)
# The organic head is one curved skull mesh with individually placed eyes, muzzle and external ears.
head=[(0,.012,1.51,.051,.056),(0,.025,1.55,.069,.076),(0,.027,1.595,.120,.101),(0,.012,1.642,.151,.125),(0,.003,1.711,.143,.122),(0,-.002,1.777,.112,.098),(0,-.015,1.823,.077,.075),(0,-.016,1.847,.041,.045)]
loft('Sculpted fox skull',head,[fur,soft],36,lambda k,i:int(k<3 and 3<i<15))
# Muzzle loft is aligned with its longitudinal axis, narrowing smoothly to the nose.
rows=[(0,.076,1.614,.095,.06),(0,.115,1.604,.086,.059),(0,.159,1.591,.067,.048),(0,.198,1.591,.047,.030),(0,.216,1.596,.029,.02)]
# local section x,z rather than x,y; normals fixed below by Blender.
vs=[(x+a*cos(i*pi/12),y,z+c*sin(i*pi/12)) for x,y,z,a,c in rows for i in range(24)]
fs=[(j*24+i,(j+1)*24+i,(j+1)*24+(i+1)%24,j*24+(i+1)%24) for j in range(4) for i in range(24)]
fs += [tuple(range(23,-1,-1)),tuple(range(96,120))]
mesh('Continuous tapered muzzle',vs,fs,[soft,fur],[int(((i%24) in range(3,9)) and i<72) for i in range(len(fs))],1)
ell('Shaped fox nose',(0,.220,1.610),(.031,.025,.018),dark)
for s in [-1,1]:
 # sculpted eyes are oblique, with narrowed natural lids, not protruding spheres.
 e=ell('Eye almond',(s*.076,.105,1.691),(.036,.013,.021),dark);e.rotation_euler.z=-s*.53;e.rotation_euler.y=-s*.14
 e=ell('Visible eye surface',(s*.075,.112,1.690),(.030,.009,.014),eye);e.rotation_euler.z=-s*.51
 ell('Amber iris',(s*.066,.122,1.690),(.013,.005,.014),amber);ell('Vertical pupil',(s*.066,.127,1.690),(.005,.003,.011),dark,16)
 line('Upper eyelid',[(s*.043,.116,1.69),(s*.069,.122,1.705),(s*.095,.110,1.703),(s*.109,.097,1.693)],brown,.0038)
 line('Expressive brow',[(s*.046,.117,1.719),(s*.073,.116,1.732),(s*.109,.088,1.726)],brown,.006)
 line('Fine mouth corner',[(0,.214,1.584),(s*.042,.189,1.571),(s*.065,.15,1.572)],brown,.0029)
 # Sculpted cheek volume tapers to the jaw without adding pointed cube tufts.

 er=[(s*.090,-.026,1.780,.074,.040),(s*.108,-.028,1.822,.066,.038),(s*.129,-.030,1.878,.052,.030),(s*.157,-.026,1.955,.029,.019),(s*.169,-.022,1.991,.010,.011),(s*.169,-.021,2.004,.003,.003)]
 loft('Organic swept fox ear',er,[fur,inner,brown],24,lambda k,i:2 if k>=4 else int(3<i<10 and 0<k<4))
# Low, organic tail follows the walking silhouette, with a color break at its softly curved tip.
tail=[(.155,-.455,.45,.011,.014),(.142,-.458,.48,.034,.041),(.109,-.453,.54,.071,.072),(.075,-.419,.63,.090,.081),(.047,-.366,.74,.088,.077),(.022,-.298,.84,.071,.068),(0,-.225,.94,.055,.051),(0,-.136,1.015,.045,.044)]
loft('Tapered russet tail',tail,[fur,soft],28,lambda k,i:int(k<2))
# Belt bag hugs the hip; a hand-stitched crossbody diagonal traces the tailored coat.
line('Leather crossbody strap',[(-.099,.070,1.447),(-.094,.122,1.385),(-.004,.138,1.285),(.09,.127,1.17),(.172,.105,1.055),(.197,.051,1.019)],bag,.013)
line('Crossbody rear strap',[(-.099,.071,1.447),(-.129,-.064,1.42),(-.084,-.121,1.33),(.061,-.113,1.162),(.185,-.051,1.06),(.197,.051,1.019)],bag,.013)
block('Leather hip satchel',(.211,.043,.944),(.145,.12,.153),bag,.022)
block('Folded satchel flap',(.218,.105,.980),(.146,.019,.080),bag,.010)
line('Satchel hand stitching',[(.154,.117,.987),(.171,.121,.953),(.254,.121,.953),(.280,.117,.984)],metal,.0021)
ell('Satchel button',(.214,.121,.960),(.009,.005,.010),metal,12)
# Recalculate tiny loft shells before export.
b.context.preferences.filepaths.save_version=0
for o in tuple(b.context.scene.objects):
 if o.type=='MESH' and o.modifiers and o.modifiers[0].type=='SUBSURF':
  b.ops.object.select_all(action='DESELECT');o.select_set(True);b.context.view_layer.objects.active=o;b.ops.object.mode_set(mode='EDIT');b.ops.mesh.select_all(action='SELECT');b.ops.mesh.normals_make_consistent(inside=False);b.ops.object.mode_set(mode='OBJECT')
b.ops.wm.save_as_mainfile(filepath=D+'/rowan-fox-pedestrian.blend')
b.ops.object.select_all(action='SELECT');b.context.view_layer.objects.active=next(o for o in b.context.scene.objects if o.type=='MESH')
b.ops.object.convert(target='MESH')
b.ops.object.join()
b.context.object.name='Rowan fox pedestrian • static art'
b.ops.export_scene.gltf(filepath=D+'/rowan-fox-pedestrian.glb',export_format='GLB',use_selection=True,export_yup=True,export_apply=True)
scene=b.context.scene;scene.render.engine='CYCLES';scene.cycles.samples=48;scene.cycles.use_denoising=False;scene.render.resolution_x=560;scene.render.resolution_y=720;scene.render.resolution_percentage=100
scene.world.color=(.23,.22,.22)
b.ops.mesh.primitive_plane_add(size=2000,location=(0,0,.010));b.context.object.data.materials.append(mat('Slate studio',(.10,.125,.15)))
for pos,units,w in [((3.5,4,5),650,4.1),((-4,2,3),380,3),((2,-4,4),640,3.2)]:
 b.ops.object.light_add(type='AREA',location=pos);o=b.context.object;o.data.energy=units;o.data.shape='DISK';o.data.size=w;o.rotation_euler=(Vector((0,0,1.15))-o.location).to_track_quat('-Z','Y').to_euler()
b.ops.object.camera_add();cam=b.context.object;scene.camera=cam;cam.data.type='ORTHO';cam.data.ortho_scale=2.35
for name,pos in [('front',(1.25,6.8,1.38)),('profile',(6.4,.23,1.43)),('rear',(-2.1,-6.4,1.38))]:
 cam.location=pos;cam.rotation_euler=(Vector((0,0,1.02))-cam.location).to_track_quat('-Z','Y').to_euler();scene.render.filepath=D+'/'+name+'.png';b.ops.render.render(write_still=True)
