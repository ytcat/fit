# Rowan — Fox street pedestrian
Original modeled Blender submission: a rounded fox head with local shaped eyes and tapered muzzle; fitted field jacket, knit collar, tailored trousers and leather ankle boots; separate natural fingers and a satchel with a strap that follows the coat. Static art-turnaround, no rig, animation, integration or phone performance claim.

- Review: Rowan-Fox-Review.jpg (three 48-sample Blender Cycles views and an 83 px silhouette inset).
- Source: rowan-fox-pedestrian.blend, editable parts, and fox.py.
- Delivery GLB: rowan-fox-pedestrian.glb, single mesh batched by material, +Y upright and -Z forward in GLB coordinates.
- check.py reimports GLB in Blender; GLB-QA.json records dimensions and limits. For a crowd, develop skin weighting, reduce material and triangle budgets or add an LOD first. No donor assets, TRELLIS or GPU service.
