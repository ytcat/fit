import bpy as b,json,struct,pathlib
from mathutils import Vector
d=pathlib.Path(__file__).parent;f=d/'rowan-fox-pedestrian.glb';raw=f.read_bytes();n,=struct.unpack_from('<I',raw,12);g=json.loads(raw[20:20+n]);b.ops.object.select_all(action='SELECT');b.ops.object.delete(use_global=False);b.ops.import_scene.gltf(filepath=str(f))
o=[o for o in b.context.scene.objects if o.type=='MESH'];assert o and not any(o.type=='ARMATURE' for o in b.context.scene.objects)
ps=[m.matrix_world@Vector(p) for m in o for p in m.bound_box];ll=[min(p[k] for p in ps) for k in range(3)];hh=[max(p[k] for p in ps) for k in range(3)];assert 1.91<hh[2]<2.05 and -.01<ll[2]<.021
s={'bytes':len(raw),'triangles':sum(g['accessors'][p['indices']]['count']//3 for m in g['meshes'] for p in m['primitives']),'nodes':len(g['nodes']),'materials':len(g['materials']),'primitives':sum(len(m['primitives']) for m in g['meshes']),'dimensions_metres':[round(h-l,3) for l,h in zip(ll,hh)],'rigged':False}
(d/'GLB-QA.json').write_text(json.dumps(s,indent=2)+'\n');print(s)
