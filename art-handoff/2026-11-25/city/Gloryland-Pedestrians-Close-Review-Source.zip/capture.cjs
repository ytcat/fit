const fs=require('node:fs'),path=require('node:path');
const root=process.argv[2],p=x=>path.resolve(root,x),T=global.THREE=require(p('assets/vendor/three.min.js'));
global.window=global;global.ArenaSets=require(p('arena-sets.js'));
require(p('adventure/story/dog-walker.js'));require(p('adventure/story/street-life.js'));
const phases=[.09,.28,.72];
const result=StreetLife.walkers.map(look=>{
 const m=StreetLife.walker(look),rig=m.skeleton,all=[[],[]];
 for (let tier=0;tier<2;tier++) {
  StreetLife.setWalkerNear(m,!!tier);
  const g=m.geometry, P=g.attributes.position, N=g.attributes.normal;
  for(const phase of phases){
   StreetLife.walkPose(m,phase);m.updateMatrixWorld(true);rig.update();
   const out=[],normal=[];
   for(let i=0;i<P.count;i++){
    const v=new T.Vector3().fromBufferAttribute(P,i),tip=v.clone().add(new T.Vector3().fromBufferAttribute(N,i).multiplyScalar(.005));
    m.boneTransform(i,v);m.boneTransform(i,tip);
    out.push(v.toArray());normal.push(tip.sub(v).normalize().toArray());
   }
   all[tier].push({p:out,n:normal,ix:Array.from(g.index.array),col:Array.from(g.attributes.color.array)});
  }
 }
 StreetLife.disposeWalker(m);return all;
});
fs.writeFileSync(process.argv[3],JSON.stringify(result));
