from PIL import Image,ImageDraw,ImageFont
import numpy as np, math,json,sys
from pathlib import Path
root=Path(__file__).parent
D=json.loads((root/'mesh-poses.json').read_text())
im=Image.new('RGB',(1260,2200),'#10191d'); d=ImageDraw.Draw(im)
font=lambda sz,b=False:ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans'+('-Bold' if b else '')+'.ttf',sz)
def txt(x,y,s,z=24,c='#f1f5f5',b=False):d.text((x,y),s,font=font(z,b),fill=c)
def render(m,az,ww=192,hh=326,detail=False):
 f=np.array([math.sin(az),.10,math.cos(az)]);f/=np.linalg.norm(f)
 r=np.cross([0,1,0],f);r/=np.linalg.norm(r);u=np.cross(f,r)
 p=np.array(m['p']);scale=350 if detail else 136
 P=np.c_[ww/2+scale*(p@r),hh-28+(1.08*scale if detail else 0)-scale*(p@u)]
 I=np.array(m['ix']).reshape(-1,3); g=p[I];n=np.array(m['n'])
 normals=np.cross(g[:,1]-g[:,0],g[:,2]-g[:,0]);visible=normals@f>0
 light=(f*.52+np.array([-.35,.82,.11]));light/=np.linalg.norm(light)
 rgb=np.clip(np.array(m['col']).reshape(-1,3)*(.59+.48*np.maximum(0,n@light))[:,None],0,1)
 bg=Image.new('RGB',(ww,hh),'#34434a');d0=ImageDraw.Draw(bg)
 d0.line((0,hh-28,ww,hh-28),fill='#42545a',width=1)
 d0.ellipse((49,hh-38,143,hh-20),fill='#28353b')
 img=np.array(bg); depth=np.full(img.shape[:2],-np.inf,dtype=float)
 for i in np.where(visible)[0]:
  ix=I[i]; q=P[ix]; z=p[ix]@f
  ax,ay=np.maximum(0,np.floor(q.min(axis=0))).astype(int)
  bx,by=np.minimum([ww-1,hh-1],np.ceil(q.max(axis=0))).astype(int)
  if ax>bx or ay>by:continue
  U,V=q[1]-q[0],q[2]-q[0];det=U[0]*V[1]-U[1]*V[0]
  if abs(det)<1e-8:continue
  X,Y=np.meshgrid(np.arange(ax,bx+1)+.5-q[0,0],np.arange(ay,by+1)+.5-q[0,1])
  a=(X*V[1]-Y*V[0])/det; b=(Y*U[0]-X*U[1])/det
  zh=z[0]+a*(z[1]-z[0])+b*(z[2]-z[0])
  tmp=depth[ay:by+1,ax:bx+1];show=(a>=0)&(b>=0)&(a+b<=1)&(zh>tmp)
  if not np.any(show):continue
  tmp[show]=zh[show]
  c0,c1,c2=rgb[ix]; yy=(c0+a[show,None]*(c1-c0)+b[show,None]*(c2-c0))
  img[ay:by+1,ax:bx+1][show]=np.round(np.clip(yy,0,1)**(1/2.2)*255)
 return Image.fromarray(img)
txt(35,32,'GLORY OF THE RING  /  CITY ART',24,'#79ccba',True)
txt(35,73,'Street characters, up close',52,b=True)
txt(35,146,'Matched walking poses, three directions. Actual skinned meshes, rendered offline.',24,'#b0c6c7')
names=['Rabbit / hoodie','Bear / tote','Fox / burgundy jacket','Dog / charcoal jacket']
for r,(name,models) in enumerate(zip(names,D)):
 y=220+r*466; d.line((35,y-13,1220,y-13),fill='#416169',width=2);txt(35,y,name,35,b=True)
 for j,(angle,az) in enumerate([('FRONT',.29),('PROFILE',math.pi/2),('BACK',math.pi+.30)]):
  x=36+j*408;txt(x,y+51,angle,21,'#8fc5b8',True)
  for k in range(2):
   xx=x+k*196;im.paste(render(models[k][j],az),(xx,y+108));txt(xx,y+81,'Street tier' if k==0 else 'Close tier',18)
txt(35,2092,'Same skeleton and route. High detail is reserved for nearby pedestrians.',23,'#b0c6c7')
im.crop((0,0,1260,2140)).save(root/'Gloryland-Pedestrians-Close-Review.png',optimize=True)

im=Image.new('RGB',(1260,1150),'#10191d'); d=ImageDraw.Draw(im)
txt(35,28,'GLORY OF THE RING  /  DETAIL STUDIES',24,'#79ccba',True)
txt(35,66,'Faces, fabric and back silhouettes',47,b=True)
txt(35,137,'Left: earlier street model   •   Right: close-up candidate',26,'#b0c6c7')
for row,(name,models) in enumerate(zip(names,D)):
 y=204+(row//2)*447; x0=35+(row%2)*614
 txt(x0,y,name,30,b=True)
 for j,az in enumerate([.42,math.pi+.35]):
  for k in range(2):
   x=x0+j*302+k*147
   im.paste(render(models[k][0],az,144,345,detail=True),(x,y+63))
  txt(x0+j*302,y+41,'FRONT ¾' if j==0 else 'REAR ¾',17,'#8fc5b8',True)
im.crop((0,0,1260,1080)).save(root/'Gloryland-Pedestrians-Detail-Compare.png',optimize=True)
