"""Build and export original right-facing five-door city compact. Blender 3.x."""
import bpy, math, os, sys
from mathutils import Vector
from math import sin,cos,pi
out=os.path.dirname(os.path.abspath(__file__))
bpy.ops.wm.read_factory_settings(use_empty=True)
def mat(name,rgba,metal,rough):
 m=bpy.data.materials.new(name);m.diffuse_color=(*rgba,1);m.use_nodes=True
 p=m.node_tree.nodes.get('Principled BSDF'); p.inputs['Base Color'].default_value=(*rgba,1);p.inputs['Metallic'].default_value=metal;p.inputs['Roughness'].default_value=rough
 return m
mats=[
 mat('enamel · warm ivory',(.73,.68,.55),.27,.37),
 mat('rubber and lower trim',(.023,.029,.032),0,.77),
 mat('blue-grey opaque glazing',(.055,.115,.15),.16,.31),
 mat('satin metal',(.42,.48,.49),.55,.38),
 mat('warm headlamps',(.94,.80,.48),.12,.35),
 mat('red rear lenses',(.54,.043,.031),.02,.39)]
car=bpy.data.collections.new('Gloryland compact · metres · +X nose');bpy.context.scene.collection.children.link(car)
def mesh(name,v,f,m,smooth=False):
 data=bpy.data.meshes.new(name);data.from_pydata(v,[],f);data.update()
 o=bpy.data.objects.new(name,data);car.objects.link(o);data.materials.append(mats[m]);
 for p in data.polygons: p.use_smooth=smooth
 return o
# Rings have equal vertex counts, starting in the same clockwise order.
def shell(name,rows,m,smooth=False):
 n=len(rows[0]);v=sum(rows,[]);f=[tuple(range(n-1,-1,-1))]
 for i in range(len(rows)-1):
  for j in range(n): f.append((i*n+j,i*n+(j+1)%n,(i+1)*n+(j+1)%n,(i+1)*n+j))
 f.append(tuple(range(len(v)-n,len(v))))
 o=mesh(name,v,f,m,smooth)
 # Ensures signed normals independent of section ordering.
 bpy.context.view_layer.objects.active=o;o.select_set(True)
 bpy.ops.object.mode_set(mode='EDIT');bpy.ops.mesh.select_all(action='SELECT');bpy.ops.mesh.normals_make_consistent(inside=False);bpy.ops.object.mode_set(mode='OBJECT');o.select_set(False)
 return o
# x, half width, rocker height, shoulder height, top height.
co=[(-2.05,.68,.47,.70,.80),(-1.99,.80,.39,.79,.88),(-1.71,.89,.33,.83,.92),(-1.28,.91,.33,.84,.94),(-.48,.90,.33,.85,.95),(.65,.90,.33,.84,.94),(1.30,.89,.34,.81,.91),(1.78,.84,.39,.72,.81),(2.02,.75,.46,.65,.73),(2.075,.64,.52,.61,.69)]
shell('Rounded lower unibody',[[(x,y,h) for y,h in [(-w*.8,l),(-w,l+.11),(-w,s-.08),(-w*.96,s),(-w*.78,t),(0,t+.015),(w*.78,t),(w*.96,s),(w,s-.08),(w,l+.11),(w*.8,l),(0,l-.035)]] for x,w,l,s,t in co],0)
# Wheels are visually cut out by opaque local recessed arches, no holes in aerodynamic body mesh.
def polybox(name,points,q,m): return shell(name,[points,[(x+q[0],y+q[1],z+q[2]) for x,y,z in points]],m)
# Cabin structural volume and color-window inset. Glass is not transparent: no environment/texture/sort dependency.
lower=[(-1.67,-.74,.89),(-1.43,-.81,.91),(.58,-.79,.93),(.90,-.68,.94),(.90,.68,.94),(.58,.79,.93),(-1.43,.81,.91),(-1.67,.74,.89)]
upper=[(-1.33,-.54,1.52),(-1.23,-.60,1.57),(.11,-.57,1.55),(.24,-.48,1.51),(.24,.48,1.51),(.11,.57,1.55),(-1.23,.60,1.57),(-1.33,.54,1.52)]
shell('Painted roof, A–C pillars and full cabin', [lower,upper],0)
def pane(name, side, u0,u1,v0,v1, ofs):
 p=[]
 for u,v in [(u0,v0),(u1,v0),(u1,v1),(u0,v1)]:
  j,k=side
  a=Vector(lower[j]).lerp(Vector(lower[k]),u);b=Vector(upper[j]).lerp(Vector(upper[k]),u)
  p.append(tuple(a.lerp(b,v)+Vector(ofs)))
 # Bilinear panel may be slightly warped relative to stock triangulation, use generous exterior offset.
 polybox(name,p,tuple(-x*.45 for x in ofs),2)
for side,sign in [((1,2),-1),((6,5),1)]:
 for name,u0,u1,v0,v1 in [('quarter glass',.027,.16,.12,.84),('rear door glass',.185,.548,.096,.89),('front door glass',.574,.974,.096,.89)]:
  pane(name,side,u0,u1,v0,v1,(0,sign*.018,0))
pane('Windshield', (3,4),.07,.93,.09,.89,(.026,0,.006))
pane('Hatch glass', (7,0),.08,.92,.13,.88,(-.025,0,.009))
for side,sign in [((2,3),-1),((5,4),1)]: pane('Front quarter glass',side,.06,.86,.12,.83,(.008,.022*sign,.008))
def box(name,x,y,z,a,b,c,m,bevel=0):
 bpy.ops.mesh.primitive_cube_add(size=1,location=(x,y,z));o=bpy.context.object;o.name=name
 for col in list(o.users_collection):col.objects.unlink(o)
 car.objects.link(o);o.dimensions=(a,b,c);bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);o.data.materials.append(mats[m])
 if bevel:
  n=o.modifiers.new('Single-segment rolled edge','BEVEL');n.width=bevel;n.segments=1
  bpy.ops.object.modifier_apply(modifier=n.name)
 return o
def lathe(name,x,y,z,sections,m,n=12):
 return shell(name,[[(x+r*cos(i*2*pi/n),y+d,z+r*sin(i*2*pi/n)) for i in range(n)] for d,r in sections],m)
for x in [-1.28,1.25]:
 for s in [-1,1]:
  # Semi-ring over the tyre reads as the recessed dark arch cap.
  yy=s*.931;v=[];f=[]
  for j in range(11):
   a=j*pi/10;v.extend([(x+.32*cos(a),yy,.306+.32*sin(a)),(x+.375*cos(a),yy,.306+.375*sin(a))])
  for j in range(10):f.append(tuple((j*2,j*2+1,j*2+3,j*2+2) if s==1 else (j*2+2,j*2+3,j*2+1,j*2)))
  mesh('Wheel recess edge',v,f,1)
  lathe('12-sided tyre',x,s*.80,.30,[(-.153,.235),(-.132,.283),(-.086,.30),(.086,.30),(.132,.283),(.153,.235)],1)
  lathe('Inset alloy wheel',x,s*.95,.30,[(-.012,.187),(.012,.187)],3)
  lathe('Dark axle hub',x,s*.966,.30,[(-.006,.071),(.006,.071)],1)
for s in [-1,1]:
 box('Side mirror body',.47,s*.937,1.00,.22,.213,.096,0,.025)
 box('Side mirror smoked insert',.375,s*.953,1.00,.013,.138,.057,2,.003)
 for x in [-.35,-1.02]: box('Flush door handle',x,s*.903,.788,.136,.025,.032,3,.006)
 # Headlight and tail lights use differently angled compact corner housings.
 for x,m,n,a in [(1.975,4,'Wrapped front lamp',.18),(-2.00,5,'Wrapped rear light',-.18)]:
  o=box(n,x,s*.62,.718,.13,.286,.10,m,.025);o.rotation_euler.z=s*a
 box('Lower rocker',0,s*.824,.40,1.71,.108,.064,1,.028)
box('Dark front grille',2.036,0,.558,.102,1.00,.103,1,.022)
box('Front grille satin bar',2.087,0,.566,.018,.71,.017,3,.006)
box('Rear shadow line',-2.050,0,.558,.067,1.07,.095,1,.022)
box('Rear plate',-2.088,0,.567,.024,.32,.10,4,.011)
box('Roof rails left',-.54,-.47,1.569,1.27,.037,.035,1,.011)
box('Roof rails right',-.54,.47,1.569,1.27,.037,.035,1,.011)
# Keep separate editable surfaces in .blend; r128 runtime mergers batch by material.
bpy.ops.object.select_all(action='DESELECT')
for o in car.objects: o.select_set(True)
bpy.ops.export_scene.gltf(filepath=os.path.join(out,'gloryland-compact.glb'),export_format='GLB',use_selection=True,export_yup=True,export_texcoords=False,export_tangents=False)
sc=bpy.context.scene
sc.render.engine='BLENDER_WORKBENCH'; sh=sc.display.shading
sh.light='STUDIO';sh.studiolight_rotate_z=.45;sh.color_type='MATERIAL';sh.show_cavity=True;sh.cavity_type='BOTH';sh.curvature_ridge_factor=1.25;sh.curvature_valley_factor=1.2;sh.show_shadows=True;sh.show_specular_highlight=True;sh.background_type='WORLD'
sc.world=bpy.data.worlds.new("Studio"); sc.world.color=(.11,.13,.16)
sc.render.resolution_x=960;sc.render.resolution_y=600;sc.render.resolution_percentage=100;sc.render.image_settings.file_format='PNG'
bpy.ops.object.camera_add();cam=bpy.context.object;cam.data.type='ORTHO';cam.data.ortho_scale=5.66;sc.camera=cam
def view(at,tag):
 cam.location=at;cam.rotation_euler=(Vector((0,0,.68))-cam.location).to_track_quat('-Z','Y').to_euler()
 sc.render.filepath=os.path.join(out,tag+'.png')
 if tag=='compact-front-quarter': bpy.ops.wm.save_as_mainfile(filepath=os.path.join(out,'gloryland-compact.blend'))
 bpy.ops.render.render(write_still=True)
view((7,-8,4.6),'compact-front-quarter')
view((-7,8,4.4),'compact-rear-quarter')
