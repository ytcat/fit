# Gloryland City Art · Wave 01
**Built by Dot. Claude's job is integration and device review, not building the upgrades from scratch.**

The implemented patch targets `ytcat/fit` at exact commit
`2508be160a025dfc8526221afc28a31001fff940` (v1.94). It does not change
the displayed version or include a release commit. Nothing was pushed or published.

## What the patch changes

| Area | Implemented | Preserved |
|---|---|---|
| Pavement pedestrians | Four distinct species-specific skinned civilians with shaped clothes, faces and shoes; optional hand-bound tote; planted gait and small head motion. | Existing routes, spawn/quality limits, walking and avoidance logic, old-rig fallback, bus dog-and-leash pair. One draw per person; 636–816 triangles depending on the look. |
| Cars | Replaced the shared full-town box car mesh with a shaped compact: sloped opaque glazing, wheels, bumpers and lamps. Map and free walk both use the new geometry. | Existing paint palette and instancing; facing, lane logic and collision; separate authored close-up opening-film cars. 328 triangles/car vs 48, adding up to 3,360 triangles for 12 active cars. One model in multiple colors, not a fleet redesign. |
| Pier fairground | Twin structural rails, braced spokes and bearings, and 16 framed, glazed cabins animated on the existing wheel. | Site and scale, wheel speed and radius, all cabins remain level, existing day/night render-batch count. No ride interaction or route changes. |

The comparatives in `review/` are renders of the actual before/after mesh data
under matched model-view lighting, not captures from the game or a physical phone.
`studio/` is optional editable Blender source and a separate close-up concept GLB.
Do not add or load it by default: the building/traffic patch creates a lighter
instanced runtime mesh in code with no extra GLB download.

## Apply and check (Claude)

1. Inspect current main and any overlapping art PRs, then branch from current main.
   If it has advanced, apply with three-way merge and review all conflicts instead
   of overwriting Claude's edits or resetting versions. Do not reuse old PR #40.
2. From the root of the branch:
   ```sh
   git apply --check /path/to/Gloryland-City-Art.patch
   git apply /path/to/Gloryland-City-Art.patch
   python3 scripts/build_offline_manifest.py
   git diff --check
   node tests/city-art-batches.test.cjs
   node tests/city-pedestrian-art.test.cjs
   node tests/free-walk.test.cjs
   node tests/offline-version-match.test.cjs
   ```
   On a newer Git baseline, if the check fails, use `git apply --3way` on the
   review branch, resolve per file and rerun tests. Drop the preview cache suffix
   when adapting to the genuine next release version, then regenerate manifest.
   The map's script URLs in `index.html`, adventure map, story sets and Free Walk
   must agree. Do not set the app version back to 1.94.
3. Run full CI and compare the native iPhone Safari view in Old Town, Market and
   Fair at default zoom and close-up in day and night. Check palette and car
   collision, varied silhouettes and shoe contact, wheel cabin clearance and
   lighting, smooth touch control and stable frame rate. Compare at the same
   location and camera, and return to the story without losing saves.
4. Publish only after approval and the usual release checks.

See `QA.txt` for local results. No TRELLIS.2, paid service, new dependency, or
external asset upload. Local browser launch was blocked by the execution
environment. Three.js and CPU geometry checks are not mobile compatibility proof.
The base version has an unrelated known opening-film strap-arm clearance failure
in the prior Lion CI. Do not ignore that gate or count this patch as its fix.

## Next visual pass (not included)

- Cars: add distinctly different silhouettes for a delivery van and taxi without
  using a draw call per car; keep the separate detailed cinematics.
- Fairground: replace the remaining boxy tram and cart props where visible,
  separate ride hubs, and improve day/night materials from actual phone views.
- Streets: audit storefront canopies, benches, street signs and vegetation at
  walking height; prioritize what the player sees in Old Town, Market and Docks.
